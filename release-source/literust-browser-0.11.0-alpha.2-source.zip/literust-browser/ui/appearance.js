// Local-only appearance catalog. No fonts, images, network calls or extra WebViews.
(() => {
  const palettes=[['Шалфей',155],['Океан',205],['Лаванда',265],['Роза',335],['Янтарь',35],['Мята',175],['Индиго',235],['Коралл',12],['Лайм',85],['Орхидея',295],['Графит',215]];
  const modes=['Ночь','Тёмная','Светлая','Бумага','Контраст'];
  window.appearanceDesigns=['Орбита','Минимализм','Студия','Классика','Терминал'];
  window.appearanceThemes=palettes.flatMap(([name,h],p)=>modes.map((mode,m)=>({name:`${name} · ${mode}`,h,m,s:p===10?6:24})));
  let style, lastKey;
  window.applyAppearance=({design=0,theme=0}={})=>{
    design=Number.isInteger(design)&&design>=0&&design<5?design:0;
    const t=window.appearanceThemes[theme]||window.appearanceThemes[0];
    const key=design+':'+theme;
    if(key===lastKey)return;
    lastKey=key;
    const light=t.m===2||t.m===3, contrast=t.m===4;
    const color=(s,l)=>`hsl(${t.h} ${s}% ${l}%)`;
    const bg=light?color(t.s,t.m===3?94:97):contrast?'#000':color(t.s,t.m===0?7:13);
    const surface=light?color(t.s,91):contrast?'#080808':color(t.s,t.m===0?13:20);
    const text=light?'#17212b':'#f2f5fa',muted=light?'#475569':'#b6c1cf';
    const accent=light?color(65,30):color(65,76),line=light?color(16,65):color(16,40);
    const radius=[14,5,22,2,0][design];
    document.documentElement.dataset.design=String(design);
    document.documentElement.dataset.theme=String(theme);
    if(!style){style=document.createElement('style');document.head.append(style);}
    style.textContent=`
      :root{color-scheme:${light?'light':'dark'};--bg:${bg};--surface:${surface};--text:${text};--muted:${muted};--accent:${accent};--line:${line};--radius:${radius}px}
      html,body{background:var(--bg);color:var(--text)}
      body{font-family:${design===4?'Consolas,monospace':'Segoe UI,Arial,sans-serif'}}
      .tab,.address-wrap,#menu,form,.entry,#filter,.symbol,.theme-choice,.design-choice{background:var(--surface);border-color:var(--line);color:var(--text);border-radius:var(--radius)}
      .tab{border-radius:var(--radius) var(--radius) 0 0}.tab.active{background:var(--bg);border-color:var(--accent);color:var(--text);box-shadow:inset 0 3px var(--accent)}
      .tabs{border-color:var(--line)}.btn,.new,.tab-close,#menu button,#address,input,#filter{color:var(--text)}
      .btn:hover,.new:hover,#menu button:hover,a.entry:hover{background:var(--surface);color:var(--accent)}
      .address-wrap:focus-within,form:focus-within{outline:2px solid var(--accent);outline-offset:1px}
      p,footer,small,.empty,.mark{color:var(--muted)}.secure,.eyebrow,.symbol,.tag,.btn.active{color:var(--accent)}
      input::placeholder,#address::placeholder{color:var(--muted)}.favicon,form button{background:var(--accent);color:var(--bg)}
      .symbol{border-color:var(--accent)}form,.entry{box-shadow:none}.entry:hover{border-color:var(--accent)}
      button:focus-visible,a:focus-visible,select:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
      ${design===1?'.symbol{display:none}h1{font-weight:400}.tab{border:0}.address-wrap{border:0;border-bottom:1px solid var(--line)}':''}
      ${design===2?'.tabs{gap:10px}.tab{border-radius:18px;margin-bottom:3px;height:32px}.address-wrap{border-radius:24px}h1{letter-spacing:-2px}.symbol{transform:rotate(-8deg)}':''}
      ${design===3?'.tab{border:1px solid var(--line)}.controls{border-bottom:1px solid var(--line)}h1{font-family:Georgia,serif}main{text-align:left}':''}
      ${design===4?'h1{letter-spacing:2px}.symbol{border-style:dashed}.tab.active{box-shadow:inset 0 -3px var(--accent)}.entry{border-style:dashed}':''}
    `;
  };
})();
