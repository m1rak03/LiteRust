//! Persist only browsing metadata here. Never save passwords or cookies in JSON.
use serde::{Deserialize, Serialize};
use std::{
    fs, io,
    path::Path,
    time::{SystemTime, UNIX_EPOCH},
};
use url::Url;

pub const NEW_TAB: &str = "literust://newtab";
pub const BOOKMARKS: &str = "literust://bookmarks";
pub const HISTORY: &str = "literust://history";
pub const DOWNLOADS: &str = "literust://downloads";
pub const MAX_TABS: usize = 24;
pub const MAX_BOOKMARKS: usize = 1000;
const MAX_HISTORY: usize = 1500;
const MAX_DOWNLOADS: usize = 300;
pub(crate) const MAX_BROWSER_DATA_BYTES: u64 = 8 * 1024 * 1024;
const MAX_URL_LEN: usize = 8192;
const MAX_ADBLOCK_EXCEPTIONS: usize = 256;
const DEFAULT_LIVE_TAB_BUDGET: u8 = 3;

fn default_live_tab_budget() -> u8 {
    DEFAULT_LIVE_TAB_BUDGET
}

pub fn valid_web_url(input: &str) -> bool {
    input.len() <= MAX_URL_LEN
        && !input.chars().any(char::is_control)
        && Url::parse(input).is_ok_and(|url| {
            matches!(url.scheme(), "http" | "https")
                && url.host_str().is_some()
                && url.username().is_empty()
                && url.password().is_none()
        })
}

pub fn valid_tab_url(input: &str) -> bool {
    matches!(input, NEW_TAB | BOOKMARKS | HISTORY | DOWNLOADS) || valid_web_url(input)
}

/// Host only, never URL userinfo/path. Explicitly no parent-domain inheritance:
/// allowing ads on example.org does NOT whitelist sub.example.org.
pub fn site_host(input: &str) -> Option<String> {
    if !valid_web_url(input) {
        return None;
    }
    Url::parse(input)
        .ok()?
        .host_str()
        .map(str::to_ascii_lowercase)
}

fn normalise_host(input: &str) -> Option<String> {
    // Only hostnames are persisted, not arbitrary URLs (so no path, credentials
    // or wildcard could sneak into the exception list from an edited JSON).
    if input.len() > 253
        || input.is_empty()
        || input
            .chars()
            .any(|c| matches!(c, '/' | '@' | ':' | '*' | '?' | '#' | '\\'))
    {
        return None;
    }
    let candidate = format!("https://{input}/");
    let host = site_host(&candidate)?;
    if host != input.to_ascii_lowercase() {
        return None;
    }
    Some(host)
}

fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.as_secs())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Tab {
    #[serde(default)]
    pub id: u64,
    pub url: String,
    pub title: String,
    // History is tab-local. WebView2 native history cannot be shared safely across
    // "sleeping" URL-only tabs that all reuse one live WebView.
    #[serde(default)]
    pub back: Vec<String>,
    #[serde(default)]
    pub forward: Vec<String>,
}

impl Default for Tab {
    fn default() -> Self {
        Self::new()
    }
}

impl Tab {
    pub fn new() -> Self {
        Self {
            id: 0,
            url: NEW_TAB.to_owned(),
            title: "Новая вкладка".into(),
            back: Vec::new(),
            forward: Vec::new(),
        }
    }
    pub fn web(url: &str) -> Self {
        Self {
            id: 0,
            url: url.into(),
            title: Self::title_for(url),
            back: Vec::new(),
            forward: Vec::new(),
        }
    }
    pub fn navigate(&mut self, next: &str) {
        if !valid_tab_url(next) || self.url == next {
            return;
        }
        if valid_tab_url(&self.url) {
            self.back.push(self.url.clone());
        }
        if self.back.len() > 40 {
            self.back.remove(0);
        }
        self.forward.clear();
        self.url = next.into();
        self.title = match next {
            NEW_TAB | BOOKMARKS | HISTORY | DOWNLOADS => Self::internal(next).title,
            _ => Self::title_for(next),
        };
    }
    pub fn go_back(&mut self) -> bool {
        if let Some(previous) = self.back.pop() {
            self.forward.push(self.url.clone());
            self.url = previous;
            self.title = Self::title_for(&self.url);
            true
        } else {
            false
        }
    }
    pub fn go_forward(&mut self) -> bool {
        if let Some(next) = self.forward.pop() {
            self.back.push(self.url.clone());
            self.url = next;
            self.title = Self::title_for(&self.url);
            true
        } else {
            false
        }
    }
    fn title_for(url: &str) -> String {
        match url {
            NEW_TAB | BOOKMARKS | HISTORY | DOWNLOADS => Self::internal(url).title,
            _ => Url::parse(url)
                .ok()
                .and_then(|value| value.host_str().map(str::to_owned))
                .unwrap_or_else(|| "Сайт".to_owned()),
        }
    }
    pub fn internal(url: &str) -> Self {
        let title = match url {
            BOOKMARKS => "Закладки",
            HISTORY => "История",
            DOWNLOADS => "Загрузки",
            _ => "Новая вкладка",
        };
        Self {
            id: 0,
            url: url.into(),
            title: title.into(),
            back: Vec::new(),
            forward: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Bookmark {
    pub url: String,
    pub title: String,
    pub added_at: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HistoryEntry {
    pub url: String,
    pub title: String,
    pub visited_at: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadEntry {
    #[serde(default)]
    pub id: u64,
    pub url: String,
    pub file: String,
    pub status: String,
    pub started_at: u64,
}

/// Indices refer to the bundled, fixed palette catalog; never arbitrary CSS.
#[derive(Debug, Default, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(default)]
pub struct Appearance {
    pub design: u8,
    pub theme: u8,
}
impl Appearance {
    pub fn validated(self) -> Self {
        Self {
            design: if self.design < 5 { self.design } else { 0 },
            theme: if self.theme < 55 { self.theme } else { 0 },
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct BrowserData {
    pub appearance: Appearance,
    pub dock_position: crate::layout::DockPosition,
    pub tabs: Vec<Tab>,
    pub active: usize,
    pub bookmarks: Vec<Bookmark>,
    pub history: Vec<HistoryEntry>,
    pub downloads: Vec<DownloadEntry>,
    pub cosmetic_filter: bool,
    pub network_blocking: bool,
    /// Exact hostnames for which experimental network blocking is turned off.
    /// No passwords, URLs, cookies or path data are stored in this list.
    pub adblock_exceptions: Vec<String>,
    #[serde(default = "default_live_tab_budget")]
    pub live_tab_budget: u8,
    /// Explicit opt-in: unloading loses forms, media and page state.
    pub auto_discard: bool,
}

impl Default for BrowserData {
    fn default() -> Self {
        Self {
            appearance: Appearance::default(),
            dock_position: crate::layout::DockPosition::default(),
            tabs: vec![Tab::new()],
            active: 0,
            bookmarks: vec![],
            history: vec![],
            downloads: vec![],
            cosmetic_filter: false,
            network_blocking: false,
            adblock_exceptions: vec![],
            live_tab_budget: DEFAULT_LIVE_TAB_BUDGET,
            auto_discard: false,
        }
    }
}

impl BrowserData {
    fn read_data(path: &Path) -> io::Result<Self> {
        // Profile data is untrusted local input. Refuse huge files before
        // allocating and deserializing them.
        if fs::metadata(path)?.len() > MAX_BROWSER_DATA_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "browser-data.json too large",
            ));
        }
        use std::io::Read;
        let mut bytes = Vec::new();
        fs::File::open(path)?
            .take(MAX_BROWSER_DATA_BYTES + 1)
            .read_to_end(&mut bytes)?;
        if bytes.len() as u64 > MAX_BROWSER_DATA_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "profile grew beyond limit",
            ));
        }
        serde_json::from_slice::<Self>(&bytes)
            .map_err(|err| io::Error::new(io::ErrorKind::InvalidData, err))
    }

    /// Fail closed if existing files cannot be recovered. Never overwrite an
    /// unreadable profile with an empty default profile on the next UI event.
    pub fn load(path: &Path) -> io::Result<Self> {
        let backup = path.with_extension("json.bak");
        match Self::read_data(path) {
            Ok(data) => Ok(data.clean()),
            Err(primary_error) => match Self::read_data(&backup) {
                Ok(data) => Ok(data.clean()),
                Err(backup_error)
                    if primary_error.kind() == io::ErrorKind::NotFound
                        && backup_error.kind() == io::ErrorKind::NotFound =>
                {
                    Ok(Self::default().clean())
                }
                Err(_) => Err(primary_error),
            },
        }
    }

    pub fn clean(mut self) -> Self {
        self.appearance = self.appearance.validated();
        if !matches!(self.live_tab_budget, 1 | 3 | 5) {
            self.live_tab_budget = DEFAULT_LIVE_TAB_BUDGET;
        }
        self.tabs.retain(|t| valid_tab_url(&t.url));
        self.tabs.truncate(MAX_TABS);
        if self.tabs.is_empty() {
            self.tabs.push(Tab::new());
        }
        self.active = self.active.min(self.tabs.len() - 1);
        // Pre-v0.5 tabs had no stable ID. Also repair duplicates or zero IDs
        // so callbacks from closed/suspended WebViews never affect other tabs.
        // IDs identify a running session only. Reassign on startup to avoid
        // collisions / saturating arithmetic from hostile persisted u64::MAX.
        for (index, tab) in self.tabs.iter_mut().enumerate() {
            tab.id = index as u64 + 1;
        }
        for tab in &mut self.tabs {
            tab.title = compact_title(&tab.title);
            tab.back.retain(|url| valid_tab_url(url));
            tab.forward.retain(|url| valid_tab_url(url));
            if tab.back.len() > 40 {
                tab.back.drain(..tab.back.len() - 40);
            }
            if tab.forward.len() > 40 {
                tab.forward.drain(..tab.forward.len() - 40);
            }
        }
        let mut seen_hosts = std::collections::HashSet::new();
        self.adblock_exceptions = self
            .adblock_exceptions
            .into_iter()
            .filter_map(|value| normalise_host(&value))
            .filter(|host| seen_hosts.insert(host.clone()))
            .take(MAX_ADBLOCK_EXCEPTIONS)
            .collect();
        let mut seen_bookmarks = std::collections::HashSet::new();
        self.bookmarks.retain_mut(|b| {
            if !valid_web_url(&b.url) {
                return false;
            }
            b.url = Url::parse(&b.url)
                .map(|url| url.to_string())
                .unwrap_or_default();
            seen_bookmarks.insert(b.url.clone())
        });
        self.bookmarks.truncate(MAX_BOOKMARKS);
        for b in &mut self.bookmarks {
            b.title = compact_title(&b.title);
        }
        self.history.retain(|h| valid_web_url(&h.url));
        if self.history.len() > MAX_HISTORY {
            self.history.drain(..self.history.len() - MAX_HISTORY);
        }
        for h in &mut self.history {
            h.title = compact_title(&h.title);
        }
        if self.downloads.len() > MAX_DOWNLOADS {
            self.downloads.drain(..self.downloads.len() - MAX_DOWNLOADS);
        }
        // A previous process can terminate mid-download. Never leave a stale
        // indefinite "Downloading" label after restarting the browser.
        for entry in &mut self.downloads {
            entry.id = 0;
            if entry.status == "Загрузка" {
                entry.status = "Прервано".into();
            }
        }
        self
    }

    pub fn save(&self, path: &Path) -> io::Result<()> {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        let encoded = serde_json::to_vec_pretty(self).map_err(io::Error::other)?;
        if encoded.len() as u64 > MAX_BROWSER_DATA_BYTES {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "browser state is too large",
            ));
        }
        let backup = path.with_extension("json.bak");
        let should_refresh_backup = fs::metadata(&backup)
            .and_then(|meta| meta.modified())
            .ok()
            .and_then(|modified| modified.elapsed().ok())
            .is_none_or(|elapsed| elapsed >= std::time::Duration::from_secs(120));
        if should_refresh_backup && Self::read_data(path).is_ok() {
            crate::profile::atomic_write(&backup, &fs::read(path)?)?;
        }
        crate::profile::atomic_write(path, &encoded)?;
        Ok(())
    }

    pub fn bookmarks_as_html(&self) -> String {
        // Standard Netscape format understood by Chrome and many other browsers.
        // Escape URLs and titles: even manually edited profile JSON is untrusted.
        let mut html = String::from("<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n<TITLE>LiteRust bookmarks</TITLE>\n<H1>LiteRust bookmarks</H1>\n<DL><p>\n");
        for item in &self.bookmarks {
            if !valid_web_url(&item.url) {
                continue;
            }
            html.push_str(&format!(
                "<DT><A HREF=\"{}\" ADD_DATE=\"{}\">{}</A>\n",
                escape_html(&item.url),
                item.added_at,
                escape_html(&item.title)
            ));
        }
        html.push_str("</DL><p>\n");
        html
    }

    pub fn cycle_live_tab_budget(&mut self) -> u8 {
        self.live_tab_budget = match self.live_tab_budget {
            1 => 3,
            3 => 5,
            _ => 1,
        };
        self.live_tab_budget
    }

    pub fn adblock_exception_for(&self, url: &str) -> bool {
        site_host(url).is_some_and(|host| self.adblock_exceptions.contains(&host))
    }

    /// Returns the new exception state, or None for an unsupported/internal URL.
    pub fn toggle_adblock_exception(&mut self, url: &str) -> Option<bool> {
        let host = site_host(url)?;
        if let Some(index) = self
            .adblock_exceptions
            .iter()
            .position(|stored| stored == &host)
        {
            self.adblock_exceptions.remove(index);
            Some(false)
        } else if self.adblock_exceptions.len() < MAX_ADBLOCK_EXCEPTIONS {
            self.adblock_exceptions.push(host);
            Some(true)
        } else {
            None
        }
    }

    pub fn bookmarked(&self, url: &str) -> bool {
        let normalized = Url::parse(url).map(|u| u.to_string()).unwrap_or_default();
        self.bookmarks.iter().any(|b| b.url == normalized)
    }

    pub fn toggle_bookmark(&mut self, url: &str, title: &str) {
        if !valid_web_url(url) {
            return;
        }
        let normalized = Url::parse(url).map(|u| u.to_string()).unwrap_or_default();
        let url = normalized.as_str();
        if let Some(pos) = self.bookmarks.iter().position(|b| b.url == url) {
            self.bookmarks.remove(pos);
        } else if valid_web_url(url) {
            if self.bookmarks.len() >= MAX_BOOKMARKS {
                return;
            }
            self.bookmarks.push(Bookmark {
                url: url.into(),
                title: compact_title(title),
                added_at: now(),
            });
        }
    }

    pub fn record_visit(&mut self, url: &str, title: &str) {
        if !valid_web_url(url) {
            return;
        }
        let current = now();
        if let Some(last) = self.history.last_mut() {
            if last.url == url && current.saturating_sub(last.visited_at) < 5 {
                last.visited_at = current;
                last.title = compact_title(title);
                return;
            }
        }
        self.history.push(HistoryEntry {
            url: url.into(),
            title: compact_title(title),
            visited_at: current,
        });
        if self.history.len() > MAX_HISTORY {
            self.history.remove(0);
        }
    }

    pub fn record_download_start(&mut self, id: u64, url: String, file: String) {
        self.downloads.push(DownloadEntry {
            id,
            url,
            file,
            status: "Загрузка".into(),
            started_at: now(),
        });
        if self.downloads.len() > MAX_DOWNLOADS {
            self.downloads.remove(0);
        }
    }

    pub fn record_download_state(&mut self, id: u64, file: &Path, running: bool, success: bool) {
        // IDs are per operation, not URL: concurrent identical URLs are distinct.
        // Clearing history deliberately prevents late callbacks from recreating it.
        if let Some(entry) = self.downloads.iter_mut().rev().find(|d| d.id == id) {
            entry.status = if running {
                "Загрузка"
            } else if success {
                "Готово"
            } else {
                "Прервано / ошибка"
            }
            .into();
            entry.file = file.display().to_string();
        }
    }
}

pub fn compact_title(input: &str) -> String {
    input
        .chars()
        .filter(|c| !c.is_control())
        .take(100)
        .collect()
}

pub fn escape_html(value: &str) -> String {
    let mut result = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '&' => result.push_str("&amp;"),
            '<' => result.push_str("&lt;"),
            '>' => result.push_str("&gt;"),
            '"' => result.push_str("&quot;"),
            '\'' => result.push_str("&#39;"),
            _ => result.push(ch),
        }
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn unrecoverable_profile_is_not_silently_reset() {
        let root = std::env::temp_dir().join(format!("literust-corrupt-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let file = root.join("browser-data.json");
        fs::write(&file, b"{bad").unwrap();
        fs::write(file.with_extension("json.bak"), b"bad too").unwrap();
        assert!(BrowserData::load(&file).is_err());
        assert_eq!(fs::read(&file).unwrap(), b"{bad");
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn download_callbacks_are_correlated_and_do_not_undo_clear() {
        let mut data = BrowserData::default();
        data.record_download_start(1, "https://example.org/file".into(), "one".into());
        data.record_download_start(2, "https://example.org/file".into(), "two".into());
        data.record_download_state(1, Path::new("chosen-one"), false, true);
        assert_eq!(data.downloads[0].status, "Готово");
        assert_eq!(data.downloads[1].status, "Загрузка");
        data.downloads.clear();
        data.record_download_state(2, Path::new("two"), false, true);
        assert!(data.downloads.is_empty());
    }
    #[test]
    fn canonical_bookmarks_and_capacity_never_drop_existing() {
        let mut data = BrowserData::default();
        data.toggle_bookmark("https://EXAMPLE.org", "one");
        assert!(data.bookmarked("https://example.org/"));
        data.toggle_bookmark("https://example.org/", "one");
        assert!(data.bookmarks.is_empty());
        for n in 0..MAX_BOOKMARKS {
            data.toggle_bookmark(&format!("https://example.org/{n}"), "x");
        }
        data.toggle_bookmark("https://new.example/", "new");
        assert_eq!(data.bookmarks.len(), MAX_BOOKMARKS);
        assert!(data.bookmarked("https://example.org/0"));
        assert!(!data.bookmarked("https://new.example/"));
    }
    #[test]
    fn hostile_ids_and_old_settings_are_safe() {
        let mut data: BrowserData = serde_json::from_str(r#"{"tabs":[{"id":18446744073709551615,"url":"literust://newtab","title":"x"},{"id":18446744073709551615,"url":"literust://newtab","title":"x"}]}"#).unwrap();
        data = data.clean();
        assert_eq!(data.tabs[0].id, 1);
        assert_eq!(data.tabs[1].id, 2);
        assert!(!data.auto_discard);
    }
    #[test]
    fn restricts_restored_tabs() {
        let d = BrowserData {
            tabs: vec![Tab {
                id: 0,
                url: "javascript:alert(1)".into(),
                title: "BAD".into(),
                back: vec![],
                forward: vec![],
            }],
            ..BrowserData::default()
        };
        assert_eq!(d.clean().tabs[0].url, NEW_TAB);
    }
    #[test]
    fn bookmark_export_escapes_html_and_omits_unsafe_urls() {
        let mut data = BrowserData::default();
        data.bookmarks.push(Bookmark {
            url: "https://example.org/?q=\"<x>".into(),
            title: "A <tag> & B".into(),
            added_at: 123,
        });
        data.bookmarks.push(Bookmark {
            url: "javascript:alert(1)".into(),
            title: "Bad".into(),
            added_at: 0,
        });
        let html = data.bookmarks_as_html();
        assert!(html.contains("&lt;tag&gt; &amp; B"));
        assert!(html.contains("?q=&quot;&lt;x&gt;"));
        assert!(html.contains("ADD_DATE=\"123\""));
        assert!(!html.contains("javascript:"));
    }
    #[test]
    fn browser_state_recovers_from_corrupted_json() {
        let tmpdir = std::env::temp_dir().join(format!(
            "literust-v08-test-{}-{}",
            std::process::id(),
            now()
        ));
        fs::create_dir_all(&tmpdir).unwrap();
        let primary = tmpdir.join("browser-data.json");
        let mut data = BrowserData::default();
        data.toggle_bookmark("https://example.org/", "ok");
        data.save(&primary).unwrap();
        data.save(&primary).unwrap(); // creates last-good backup
        fs::write(&primary, b"{broken").unwrap();
        let recovered = BrowserData::load(&primary).unwrap();
        assert_eq!(recovered.bookmarks.len(), 1);
        let _ = fs::remove_dir_all(&tmpdir);
    }
    #[test]
    fn interrupted_download_is_marked_on_recovery() {
        let mut data = BrowserData::default();
        data.record_download_start(1, "https://example.org/test.zip".into(), "test.zip".into());
        assert_eq!(data.clean().downloads[0].status, "Прервано");
    }
    #[test]
    fn escape_protects_local_pages() {
        assert_eq!(
            escape_html("<a href=\"x\">&'"),
            "&lt;a href=&quot;x&quot;&gt;&amp;&#39;"
        );
    }
    #[test]
    fn bookmark_toggle_does_not_store_untrusted_scheme() {
        let mut d = BrowserData::default();
        d.toggle_bookmark("file:///etc/passwd", "x");
        assert_eq!(d.bookmarks.len(), 0);
        d.toggle_bookmark("https://example.com/", "Example");
        assert!(d.bookmarked("https://example.com/"));
        d.toggle_bookmark("https://example.com/", "Example");
        assert!(!d.bookmarked("https://example.com/"));
    }
    #[test]
    fn tab_navigation_isolated_and_persistent() {
        let mut a = Tab::new();
        let mut b = Tab::web("https://other.example/");
        a.navigate("https://example.org/one");
        a.navigate("https://example.org/two");
        assert!(a.go_back());
        assert_eq!(a.url, "https://example.org/one");
        assert!(a.go_forward());
        assert_eq!(a.url, "https://example.org/two");
        assert!(!b.go_back());
        let serialized = serde_json::to_string(&a).unwrap();
        let restored: Tab = serde_json::from_str(&serialized).unwrap();
        assert_eq!(restored.back, a.back);
    }
    #[test]
    fn upgrades_old_tabs_with_distinct_ids() {
        let mut data = BrowserData {
            tabs: vec![Tab::new(), Tab::web("https://example.org/")],
            ..BrowserData::default()
        };
        data.tabs[1].id = data.tabs[0].id;
        let restored = data.clean();
        assert_ne!(restored.tabs[0].id, restored.tabs[1].id);
        assert_ne!(restored.tabs[0].id, 0);
    }
    #[test]
    fn old_tab_json_is_compatible() {
        let old = r#"{"url":"https://example.org/","title":"Old"}"#;
        let tab: Tab = serde_json::from_str(old).unwrap();
        assert!(tab.back.is_empty() && tab.forward.is_empty());
    }
    #[test]
    fn adblock_exceptions_match_exact_hosts_and_ignore_paths() {
        let mut d = BrowserData::default();
        assert_eq!(
            d.toggle_adblock_exception("https://example.org/some/path?x=1"),
            Some(true)
        );
        assert!(d.adblock_exception_for("https://example.org/another"));
        assert!(!d.adblock_exception_for("https://sub.example.org/"));
        assert!(!d.adblock_exception_for("https://notexample.org/"));
        assert_eq!(
            d.toggle_adblock_exception("https://example.org/"),
            Some(false)
        );
        assert!(!d.adblock_exception_for("https://example.org/"));
        assert_eq!(d.toggle_adblock_exception("literust://newtab"), None);
        assert_eq!(
            d.toggle_adblock_exception("https://google.com@evil.example/"),
            None
        );
    }
    #[test]
    fn old_settings_and_host_validation() {
        let mut d: BrowserData = serde_json::from_str(r#"{"network_blocking":true}"#).unwrap();
        assert!(d.adblock_exceptions.is_empty());
        d.adblock_exceptions = vec![
            "Example.org".into(),
            "example.org".into(),
            "google.com@evil.example".into(),
            "example.org/path".into(),
            "*.other.org".into(),
        ];
        let clean = d.clean();
        assert_eq!(clean.adblock_exceptions, vec!["example.org"]);
    }
    #[test]
    fn live_tab_budget_defaults_and_cycles() {
        let mut d: BrowserData = serde_json::from_str(r#"{"network_blocking":false}"#).unwrap();
        assert_eq!(d.live_tab_budget, 3);
        assert_eq!(d.cycle_live_tab_budget(), 5);
        assert_eq!(d.cycle_live_tab_budget(), 1);
        assert_eq!(d.cycle_live_tab_budget(), 3);
        d.live_tab_budget = 255;
        assert_eq!(d.clean().live_tab_budget, 3);
    }
    #[test]
    fn persisted_data_roundtrip() {
        let tmp =
            std::env::temp_dir().join(format!("literust-{}-{}.json", std::process::id(), now()));
        let mut d = BrowserData::default();
        d.toggle_bookmark("https://example.com/", "Example");
        d.save(&tmp).unwrap();
        let read = BrowserData::load(&tmp).unwrap();
        assert!(read.bookmarked("https://example.com/"));
        let _ = fs::remove_file(tmp);
    }
}

#[cfg(test)]
mod appearance_tests {
    use super::*;
    #[test]
    fn migrates_and_validates_appearance() {
        let old: BrowserData = serde_json::from_str("{}").unwrap();
        assert_eq!(old.appearance, Appearance::default());
        let invalid: BrowserData =
            serde_json::from_str(r#"{"appearance":{"design":5,"theme":55}}"#).unwrap();
        assert_eq!(invalid.clean().appearance, Appearance::default());
        for design in 0..5 {
            for theme in 0..55 {
                let data = BrowserData {
                    appearance: Appearance { design, theme },
                    ..Default::default()
                };
                let recovered: BrowserData =
                    serde_json::from_slice(&serde_json::to_vec(&data).unwrap()).unwrap();
                assert_eq!(recovered.clean().appearance, data.appearance);
            }
        }
    }
}
