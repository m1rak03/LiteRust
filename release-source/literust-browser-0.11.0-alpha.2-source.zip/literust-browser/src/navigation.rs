use crate::storage::{valid_web_url, NEW_TAB};
use url::Url;

/// Only HTTP(S) addresses may be typed/opened. All other input is a search.
pub fn destination(input: &str) -> String {
    let input = input.trim();
    if input.is_empty() {
        return NEW_TAB.to_owned();
    }
    if valid_web_url(input) {
        return Url::parse(input).expect("validated").to_string();
    }
    let unsupported_absolute = Url::parse(input)
        .is_ok_and(|url| !matches!(url.scheme(), "http" | "https"))
        && !input.starts_with("localhost:");
    let numeric_port = input.rsplit_once(':').is_some_and(|(host, port)| {
        (host.contains('.') || host == "localhost" || host.starts_with('['))
            && port.parse::<u16>().is_ok()
    });
    let looks_like_host = (!unsupported_absolute || numeric_port)
        && !input.chars().any(char::is_whitespace)
        && !input.contains("://")
        && (input.contains('.')
            || input.eq_ignore_ascii_case("localhost")
            || input.starts_with("localhost:")
            || input.starts_with('['));
    if looks_like_host {
        let scheme = if input.starts_with("localhost") || input.starts_with("127.0.0.1") {
            "http"
        } else {
            "https"
        };
        let candidate = format!("{scheme}://{input}");
        if valid_web_url(&candidate) {
            return Url::parse(&candidate).expect("validated").to_string();
        }
    }
    let mut serializer = url::form_urlencoded::Serializer::new(String::new());
    serializer.append_pair("q", input);
    format!("https://www.google.com/search?{}", serializer.finish())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn addresses_ports_and_search() {
        assert_eq!(destination("example.org:8443"), "https://example.org:8443/");
        assert_eq!(destination("localhost:8080"), "http://localhost:8080/");
        assert_eq!(destination("[::1]:8080"), "https://[::1]:8080/");
        assert_eq!(destination("пример.рф"), "https://xn--e1afmkfd.xn--p1ai/");
        assert_eq!(
            destination("как дела"),
            "https://www.google.com/search?q=%D0%BA%D0%B0%D0%BA+%D0%B4%D0%B5%D0%BB%D0%B0"
        );
    }
}
