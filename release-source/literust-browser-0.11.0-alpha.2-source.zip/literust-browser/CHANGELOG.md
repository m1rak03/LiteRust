## 0.11.0-alpha.1

- Google-style simplified new tab: Google search, bookmarks as shortcuts, services menu, top-right sign-in, optional speech input, Lens/Gemini links.
- Top-left Google account entry opens the persistent LiteRust profile; no permanent-session or OAuth-sync claim.
- Dock on any edge with persistent position and full content-area settings/VPN panels.
- Happ-inspired VPN workspace, strict URI/subscription import, Windows DPAPI vault, bundled Xray, explicit restart, proxy fail-closed behavior and user-triggered HTTPS RTT check.
- Portable and full-runtime packages now include the VPN engine and its license/source notice.

## 0.10.0-alpha.2

- Проверка установленного WebView2 Runtime до создания native window; понятная ошибка и адрес официального установщика.
- Журнал этапов запуска в LocalAppData/LiteRustBrowser/diagnostics/startup.log.
- Новый каталог запускателя, прежний профиль браузера сохранён.

## 0.10.0-alpha.1

- Five visual designs and 55 bundled themes; validated, persistent profile preferences.
- Resizable appearance picker, keyboard focus, light/dark/contrast filters, internal-page theming.
- Compact toolbar IPC and stable tab DOM across progress updates; no duplicate start-page load.
- Explicit background WebView unloading, protecting active/loading/downloading pages.
- Official Google Account launcher alongside existing Password Manager portal; no OAuth or password-sync claim.
- Portable Windows x64 cross-build and updated UI/profile tests. See docs/UPDATE_0_10.md for verification limits.

# 0.9.0-alpha.1 — 2026-11-11

Предварительная стабилизация исходного 0.8, не стабильный релиз.

- Исправлены Wry PermissionResponse API и некомпилируемый тест истории.
- Добавлены Cargo.lock, fmt/check/Clippy в CI и платформонезависимая test library.
- Защищены профиль, резервная копия и миграция; OS lock, fail-closed восстановление,
  bounded read, сообщения ошибок сохранения/запуска.
- Автовыгрузка opt-in; активные загрузки защищены от LRU и закрытия вкладки.
- Native download dialog и ID операций вместо URL-корреляции, clear не отменяется callbacks.
- Исправлены capacity/dedup закладок и поиск библиотеки.
- Усилены URL input, IPC Source, CSP; добавлены числовые порты/IDN tests.
- Отключено новое сохранение паролей WebView2, внешний Google portal сохранён.
- 28 core tests и локальный Chromium UI test выполнены; MSVC check/Clippy проходят.
- EXE не слинкован, Windows runtime/сайты/производительность не проверены.
