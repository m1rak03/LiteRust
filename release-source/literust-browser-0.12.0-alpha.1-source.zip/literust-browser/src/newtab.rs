use crate::storage::{escape_html, valid_web_url, BrowserData};
const START_PAGE: &str = include_str!("../ui/start.html");
pub fn render(data: &BrowserData, private_mode: bool) -> String {
    let defaults = [
        ("https://www.google.com/", "Google"),
        ("https://mail.google.com/", "Почта"),
        ("https://www.youtube.com/", "YouTube"),
        ("https://ru.wikipedia.org/", "Википедия"),
    ];
    let entries: Vec<(&str, &str)> = if data.bookmarks.is_empty() {
        defaults.to_vec()
    } else {
        data.bookmarks
            .iter()
            .take(10)
            .map(|b| (b.url.as_str(), b.title.as_str()))
            .collect()
    };
    let shortcuts=entries.into_iter().filter(|(url,_)|valid_web_url(url)).map(|(url,title)|{
        let title=if title.is_empty(){url}else{title};let initial=title.chars().next().unwrap_or('◎');
        format!("<a class=\"shortcut\" href=\"{}\" title=\"{}\"><span class=\"shortcut-icon\">{}</span><span class=\"shortcut-label\">{}</span></a>",escape_html(url),escape_html(title),escape_html(&initial.to_string()),escape_html(title))
    }).collect::<String>();
    START_PAGE
        .replace("__SEARCH_NAME__", data.search_engine.name())
        .replace("__SEARCH_URL__", data.search_engine.prefix())
        .replace("<!-- SHORTCUTS -->", &shortcuts)
        .replace(
            "__PROFILE_NOTE__",
            if private_mode {
                "Приватное окно · Вход на сайты не сохраняется после закрытия"
            } else {
                "LiteRust · Сессии сайтов хранятся в вашем профиле"
            },
        )
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn safe_shortcuts_and_profile_note() {
        let mut data = BrowserData::default();
        data.toggle_bookmark("https://example.com/", "<img src=x onerror=alert(1)>");
        let html = render(&data, false);
        assert!(!html.contains("<img src=x"));
        assert!(html.contains("&lt;img"));
        assert!(html.contains("https://example.com/"));
        assert!(!html.contains("<!-- SHORTCUTS -->"));
        assert!(render(&data, true).contains("Вход на сайты не сохраняется"));
        for i in 0..20 {
            data.toggle_bookmark(&format!("https://example.com/{i}"), "Test");
        }
        assert_eq!(
            render(&data, false).matches("class=\"shortcut\"").count(),
            10
        );
    }
    #[test]
    fn selected_provider_is_rendered() {
        let data = BrowserData {
            search_engine: crate::navigation::SearchEngine::Yandex,
            ..BrowserData::default()
        };
        let html = render(&data, false);
        assert!(html.contains("https://yandex.ru/search/?text="));
        assert!(html.contains("Поиск · Яндекс"));
        assert!(!html.contains("__SEARCH_"));
    }
    #[test]
    fn default_services_and_signin() {
        let html = render(&BrowserData::default(), false);
        assert_eq!(html.matches("class=\"shortcut\"").count(), 4);
        assert!(html.contains("class=\"sign-in\" href=\"https://myaccount.google.com/\""));
        assert!(html.contains("https://www.google.com/search?q="));
    }
}
