//! LiteRust Browser 0.13-alpha.2: per-site network-filter exceptions, permission prompts,
//! URL hygiene and low-memory background views. Web rendering is Edge WebView2.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use literust_browser::{
    google_passwords, import, layout, network_block, profile, security, storage, vpn,
};
#[cfg(windows)]
mod windows_platform;

#[cfg(test)]
use literust_browser::navigation::destination;
use serde::{Deserialize, Serialize};
use std::{
    collections::HashMap,
    fs,
    io::Write,
    path::{Path, PathBuf},
    process::Command,
    time::{SystemTime, UNIX_EPOCH},
};
use storage::{
    escape_html, valid_web_url, BrowserData, Tab, BOOKMARKS, DOWNLOADS, HISTORY, MAX_TABS, NEW_TAB,
};
use tao::{
    dpi::LogicalSize,
    event::{Event, WindowEvent},
    event_loop::{ControlFlow, EventLoopBuilder, EventLoopProxy},
    window::{Window, WindowBuilder},
};
use wry::{
    dpi::{LogicalPosition, LogicalSize as WebLogicalSize},
    NewWindowResponse, PageLoadEvent, PermissionKind, PermissionResponse, Rect, WebContext,
    WebView, WebViewBuilder,
};
#[cfg(windows)]
use wry::{MemoryUsageLevel, WebViewBuilderExtWindows, WebViewExtWindows};

const TOOLBAR: &str = include_str!("../ui/toolbar.html");
const LIBRARY: &str = include_str!("../ui/library.html");
const COSMETIC_FILTER: &str = include_str!("../ui/cosmetic-filter.js");
const APPEARANCE_SCRIPT: &str = include_str!("../ui/appearance.js");
const DOCK: &str = include_str!("../ui/dock.html");
const TOOLBAR_HEIGHT: f64 = 108.0;
// All views sharing a WebView2 environment must use identical proxy options,
// including private toolbar/dock views (whose default context is shared).
fn routed_builder(builder: WebViewBuilder<'_>, port: Option<u16>) -> WebViewBuilder<'_> {
    #[cfg(windows)]
    {
        let mut args = String::from("--disable-gpu --site-per-process");
        if let Some(port) = port {
            args.push(' ');
            args.push_str(&vpn::browser_args(port));
        }
        builder
            .with_devtools(false)
            .with_additional_browser_args(args)
    }
    #[cfg(not(windows))]
    {
        let _ = port;
        builder
    }
}
// Each mode caps the number of live WebViews, not the number of saved tabs.

fn lru_victim(entries: impl IntoIterator<Item = (u64, u64)>, protected_id: u64) -> Option<u64> {
    entries
        .into_iter()
        .filter(|(id, _)| *id != protected_id)
        .min_by_key(|(_, last_used)| *last_used)
        .map(|(id, _)| id)
}

#[derive(Deserialize)]
#[serde(tag = "action", rename_all = "snake_case")]
enum UiCommand {
    VpnScope {
        system: bool,
    },
    SetCustomIcon {
        target: String,
        value: String,
        #[serde(default)]
        rgba: String,
    },
    SetCustomization {
        value: storage::Customization,
    },
    SetBackground {
        value: String,
    },
    SetSearchEngine {
        engine: literust_browser::navigation::SearchEngine,
    },
    Ready,
    ShowSettings,
    ShowAppearance,
    ShowVpn,
    VpnProbe,
    SetDock {
        position: layout::DockPosition,
    },
    VpnImport {
        value: String,
        #[serde(default)]
        kind: vpn::ImportKind,
    },
    VpnApply {
        #[serde(default)]
        system: bool,
        enabled: bool,
        selected: usize,
    },
    GoogleAccountExternal,
    Navigate {
        value: String,
    },
    Back,
    Forward,
    Reload,
    Home,
    NewTab,
    SelectTab {
        index: usize,
    },
    CloseTab {
        index: usize,
    },
    ToggleBookmark,
    ShowBookmarks,
    ShowHistory,
    ShowDownloads,
    ClearHistory,
    ExportBookmarks,
    ClearDownloadHistory,
    ImportBookmarks {
        html: String,
    },
    ClearSiteData,
    OpenGooglePasswords,
    OpenGoogleAccount,
    SetAppearance {
        design: u8,
        theme: u8,
    },
    AppearancePanel {
        open: bool,
    },
    DiscardBackground,
    NewPrivateWindow,
    ToggleCosmeticFilter,
    ToggleNetworkBlocking,
    ToggleSiteAdblock,
    CycleMemoryMode,
    ToggleAutoDiscard,
}

impl std::fmt::Debug for UiCommand {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("UiCommand(<redacted>)")
    }
}
#[derive(Debug)]
enum AppEvent {
    Ui(UiCommand),
    VpnImported(Result<Vec<vpn::Node>, &'static str>),
    VpnProbed(Result<u128, &'static str>),
    NewTabAppearance {
        tab_id: u64,
        generation: u64,
    },
    Page {
        tab_id: u64,
        generation: u64,
        url: String,
        loading: bool,
    },
    Title {
        tab_id: u64,
        generation: u64,
        title: String,
    },
    Popup {
        tab_id: u64,
        generation: u64,
        url: String,
    },
    DownloadStarted {
        id: u64,
        url: String,
        file: String,
    },
    DownloadState {
        id: u64,
        file: PathBuf,
        running: bool,
        ok: bool,
    },
}

#[derive(Serialize)]
struct ToolbarState<'a> {
    customization: storage::Customization,
    search_engine: literust_browser::navigation::SearchEngine,
    tabs: Vec<TabSummary<'a>>,
    appearance: storage::Appearance,
    dock_position: layout::DockPosition,
    vpn_enabled: bool,
    vpn_system_scope: bool,
    vpn_system_running: bool,
    vpn_running: bool,
    vpn_nodes: Vec<&'a str>,
    vpn_details: Vec<String>,
    vpn_probe: &'a str,
    vpn_probing: bool,
    vpn_selected: usize,
    vpn_importing: bool,
    active: usize,
    url: &'a str,
    loading: bool,
    bookmarked: bool,
    bookmarks: usize,
    history: usize,
    downloads: usize,
    can_back: bool,
    can_forward: bool,
    live_ids: Vec<u64>,
    private_mode: bool,
    cosmetic_filter: bool,
    network_blocking: bool,
    site_host: Option<String>,
    site_adblock_exception: bool,
    live_tab_budget: u8,
    url_warning: Option<&'static str>,
    auto_discard: bool,
}

#[derive(Serialize)]
struct TabSummary<'a> {
    id: u64,
    title: &'a str,
}

struct LivePage {
    allow_internal_navigation: std::rc::Rc<std::cell::Cell<bool>>,
    pending_html_navigation: std::rc::Rc<std::cell::Cell<bool>>,
    downloads: std::rc::Rc<std::cell::Cell<usize>>,
    view: WebView,
    last_used: u64,
    generation: u64,
    loading: bool,
}

struct Browser {
    #[cfg(windows)]
    system_vpn: Option<literust_browser::system_vpn::SystemTunnel>,
    app_icon_applied: bool,
    window: Window,
    toolbar: WebView,
    dock: WebView,
    vpn_vault: vpn::Vault,
    #[cfg(windows)]
    vpn_tunnel: Option<literust_browser::vpn_platform::Tunnel>,
    vpn_port: Option<u16>,
    vpn_running: bool,
    vpn_importing: bool,
    vpn_probe: String,
    vpn_probing: bool,
    restart_requested: bool,
    context: Option<WebContext>,
    pages: HashMap<u64, LivePage>,
    data: BrowserData,
    data_file: Option<PathBuf>,
    proxy: EventLoopProxy<AppEvent>,
    private_mode: bool,
    next_tab_id: u64,
    next_generation: u64,
    usage_clock: u64,
    appearance_open: bool,
}

impl Browser {
    #[allow(clippy::too_many_arguments)]
    fn new(
        window: Window,
        toolbar: WebView,
        dock: WebView,
        context: Option<WebContext>,
        data: BrowserData,
        data_file: Option<PathBuf>,
        proxy: EventLoopProxy<AppEvent>,
        private_mode: bool,
    ) -> Self {
        let next_tab_id = data
            .tabs
            .iter()
            .map(|tab| tab.id)
            .max()
            .unwrap_or(0)
            .saturating_add(1)
            .max(1);
        Self {
            app_icon_applied: false,
            #[cfg(windows)]
            system_vpn: None,
            window,
            toolbar,
            dock,
            vpn_vault: vpn::Vault::default(),
            #[cfg(windows)]
            vpn_tunnel: None,
            vpn_port: None,
            vpn_running: false,
            vpn_importing: false,
            vpn_probe: String::new(),
            vpn_probing: false,
            restart_requested: false,
            context,
            pages: HashMap::new(),
            data,
            data_file,
            proxy,
            private_mode,
            next_tab_id,
            next_generation: 1,
            usage_clock: 0,
            appearance_open: false,
        }
    }

    fn system_vpn_running(&self) -> bool {
        #[cfg(windows)]
        {
            self.system_vpn.as_ref().is_some_and(|tun| tun.alive())
        }
        #[cfg(not(windows))]
        {
            false
        }
    }
    fn sync_icons(&self) {
        if let Ok(json) = serde_json::to_string(&self.data.custom_icons) {
            let script = format!("window.setCustomIcons?.({json});");
            let _ = self.toolbar.evaluate_script(&script);
            let _ = self.dock.evaluate_script(&script);
        }
    }
    fn update_app_icon(&self) {
        use base64::Engine;
        let rgba = base64::engine::general_purpose::STANDARD
            .decode(&self.data.app_icon_rgba)
            .ok();
        self.window.set_window_icon(
            rgba.and_then(|bytes| tao::window::Icon::from_rgba(bytes, 64, 64).ok())
                .or_else(|| {
                    tao::window::Icon::from_rgba(
                        include_bytes!("../packaging/default-icon.rgba").to_vec(),
                        64,
                        64,
                    )
                    .ok()
                }),
        );
        #[cfg(windows)]
        if !self.private_mode {
            let root = profile_root();
            let icon = root.join("custom.ico");
            let icon_path = if let Some(bytes) = self
                .data
                .custom_icons
                .get("app")
                .and_then(|value| literust_browser::icons::ico(value))
            {
                if fs::write(&icon, bytes).is_err() {
                    return;
                }
                icon
            } else {
                let _ = fs::remove_file(&icon);
                match std::env::current_exe()
                    .ok()
                    .and_then(|p| p.parent().map(|p| p.join("literust.ico")))
                {
                    Some(p) => p,
                    None => return,
                }
            };
            // Fixed script; user-supplied image bytes never become shell code.
            let script = r#"$s=New-Object -ComObject WScript.Shell;foreach($p in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'LiteRust.lnk'),(Join-Path ([Environment]::GetFolderPath('Programs')) 'LiteRust/LiteRust.lnk'))){if(Test-Path $p){$l=$s.CreateShortcut($p);if($l.TargetPath -eq $env:LITERUST_EXE){$l.IconLocation=$env:LITERUST_ICON;$l.Save()}}}"#;
            use std::os::windows::process::CommandExt;
            let Ok(powershell) =
                security::windows_system_binary("WindowsPowerShell/v1.0/powershell.exe")
            else {
                return;
            };
            let _ = Command::new(powershell)
                .args(["-NoProfile", "-NonInteractive", "-Command", script])
                .env("LITERUST_ICON", icon_path)
                .env("LITERUST_EXE", std::env::current_exe().unwrap_or_default())
                .creation_flags(0x08000000)
                .spawn();
        }
    }

    fn persist(&self) {
        if let Some(ref file) = self.data_file {
            if let Err(err) = self.data.save(file) {
                eprintln!("Failed to persist browser state: {err}");
                self.notice(
                    "Не удалось сохранить профиль. Проверьте свободное место и права доступа.",
                );
            }
        }
    }

    fn active_id(&self) -> u64 {
        self.data.tabs[self.data.active].id
    }
    fn current_url(&self) -> &str {
        &self.data.tabs[self.data.active].url
    }

    fn sync_toolbar(&self) {
        let url = self.current_url();
        let state = ToolbarState {
            tabs: self
                .data
                .tabs
                .iter()
                .map(|t| TabSummary {
                    id: t.id,
                    title: &t.title,
                })
                .collect(),
            customization: self.data.customization,
            appearance: self.data.appearance,
            search_engine: self.data.search_engine,
            dock_position: self.data.dock_position,
            vpn_enabled: self.vpn_vault.enabled,
            vpn_system_scope: self.vpn_vault.system_scope,
            vpn_system_running: self.system_vpn_running(),
            vpn_running: self.vpn_running,
            vpn_nodes: self
                .vpn_vault
                .nodes
                .iter()
                .map(|n| n.name.as_str())
                .collect(),
            vpn_details: self.vpn_vault.nodes.iter().map(vpn::description).collect(),
            vpn_probe: &self.vpn_probe,
            vpn_probing: self.vpn_probing,
            vpn_selected: self.vpn_vault.selected,
            vpn_importing: self.vpn_importing,
            active: self.data.active,
            url: if url.starts_with("literust://") {
                ""
            } else {
                url
            },
            loading: self
                .pages
                .get(&self.active_id())
                .is_some_and(|page| page.loading),
            bookmarked: self.data.bookmarked(url),
            bookmarks: self.data.bookmarks.len(),
            history: self.data.history.len(),
            downloads: self.data.downloads.len(),
            can_back: !self.data.tabs[self.data.active].back.is_empty(),
            can_forward: !self.data.tabs[self.data.active].forward.is_empty(),
            live_ids: self.pages.keys().copied().collect(),
            private_mode: self.private_mode,
            cosmetic_filter: self.data.cosmetic_filter,
            network_blocking: self.data.network_blocking,
            site_host: storage::site_host(url),
            site_adblock_exception: self.data.adblock_exception_for(url),
            live_tab_budget: self.data.live_tab_budget,
            url_warning: security::hostname_warning(url),
            auto_discard: self.data.auto_discard,
        };
        if let Ok(payload) = serde_json::to_string(&state) {
            let dock_state = serde_json::json!({"appearance":self.data.appearance,"position":self.data.dock_position,"animations":self.data.customization.animations,"vpn_enabled":self.vpn_vault.enabled,"vpn_running":self.vpn_running && (!self.vpn_vault.system_scope || self.system_vpn_running())});
            let _ = self
                .dock
                .evaluate_script(&format!("window.dockUpdate?.({dock_state});"));
            if let Err(err) = self
                .toolbar
                .evaluate_script(&format!("window.browserUpdate?.({payload});"))
            {
                eprintln!("Cannot update toolbar: {err}");
            }
        }
    }

    fn notice(&self, message: &str) {
        if let Ok(text) = serde_json::to_string(message) {
            let _ = self
                .toolbar
                .evaluate_script(&format!("window.browserNotice?.({text});"));
        }
    }

    fn filter_enabled_for(&self, url: &str) -> bool {
        self.data.network_blocking && !self.data.adblock_exception_for(url)
    }

    fn update_filter_for_live_pages(&self) {
        #[cfg(windows)]
        for (tab_id, page) in &self.pages {
            if let Some(tab) = self.data.tabs.iter().find(|tab| tab.id == *tab_id) {
                if let Err(err) =
                    network_block::apply(&page.view, self.filter_enabled_for(&tab.url))
                {
                    eprintln!("Cannot update network filtering for tab {tab_id}: {err}");
                }
            }
        }
    }

    fn toolbar_height(&self) -> f64 {
        let height = self
            .window
            .inner_size()
            .to_logical::<f64>(self.window.scale_factor())
            .height;
        if self.appearance_open {
            height.max(TOOLBAR_HEIGHT)
        } else {
            TOOLBAR_HEIGHT
        }
    }

    fn themed_html(&self, html: String) -> String {
        let settings = serde_json::to_string(&self.data.appearance).unwrap_or_default();
        html.replace(
            "</head>",
            &format!(
                "<script>{APPEARANCE_SCRIPT}\nwindow.applyAppearance({settings});</script></head>"
            ),
        )
    }

    fn layout_bounds(&self) -> (Rect, Rect) {
        let size = self
            .window
            .inner_size()
            .to_logical::<f64>(self.window.scale_factor());
        let (dock, page) = layout::arrange(
            size.width,
            size.height,
            TOOLBAR_HEIGHT,
            self.data.dock_position,
        );
        (
            rect(dock.x, dock.y, dock.width, dock.height),
            rect(page.x, page.y, page.width, page.height),
        )
    }
    fn page_bounds(&self) -> Rect {
        self.layout_bounds().1
    }

    fn make_view(&mut self, tab_id: u64) -> wry::Result<LivePage> {
        let generation = self.next_generation;
        self.next_generation = self.next_generation.saturating_add(1);
        let load_proxy = self.proxy.clone();
        let title_proxy = self.proxy.clone();
        let popup_proxy = self.proxy.clone();
        let internal_proxy = self.proxy.clone();
        let bounds = self.page_bounds();
        let builder = if self.private_mode {
            // WebContext must not be supplied to an incognito view.
            WebViewBuilder::new().with_incognito(true)
        } else {
            WebViewBuilder::new_with_web_context(self.context.as_mut().expect("normal WebContext"))
        };
        let builder = routed_builder(builder, self.vpn_port);
        let allow_internal_navigation = std::rc::Rc::new(std::cell::Cell::new(true));
        let navigation_mode = allow_internal_navigation.clone();
        let pending_html_navigation = std::rc::Rc::new(std::cell::Cell::new(false));
        let pending_html = pending_html_navigation.clone();
        let mut builder = builder
            .with_visible(false)
            .with_bounds(bounds)
            .with_navigation_handler(move |url| {
                // NavigateToString uses a runtime-specific navigation URI. Only the
                // next application-requested HTML load receives this allowance.
                if pending_html.replace(false)
                    && (url.is_empty() || url == "about:blank" || url.starts_with("data:text/html"))
                {
                    return true;
                }
                if navigation_mode.get() && url == "literust://appearance" {
                    let _ = internal_proxy
                        .send_event(AppEvent::NewTabAppearance { tab_id, generation });
                    return false;
                }
                let allowed = permitted_page_navigation(&url)
                    && (url != "about:blank" || navigation_mode.get());
                if allowed && valid_web_url(&url) {
                    navigation_mode.set(false);
                }
                allowed
            })
            .with_permission_handler(site_permission_policy)
            .with_new_window_req_handler(move |url, _| {
                if valid_web_url(&url) {
                    let _ = popup_proxy.send_event(AppEvent::Popup {
                        tab_id,
                        generation,
                        url,
                    });
                }
                NewWindowResponse::Deny
            })
            .with_on_page_load_handler(move |event, url| {
                let _ = load_proxy.send_event(AppEvent::Page {
                    tab_id,
                    generation,
                    url,
                    loading: matches!(event, PageLoadEvent::Started),
                });
            })
            .with_document_title_changed_handler(move |title| {
                if title == "Новая вкладка" {
                    startup_log("New tab document ready");
                }
                let _ = title_proxy.send_event(AppEvent::Title {
                    tab_id,
                    generation,
                    title,
                });
            });
        if self.data.cosmetic_filter {
            builder = builder.with_initialization_script(COSMETIC_FILTER);
        }
        let view = builder.build_as_child(&self.window)?;
        #[cfg(windows)]
        if let Some(tab) = self.data.tabs.iter().find(|tab| tab.id == tab_id) {
            if self.filter_enabled_for(&tab.url) {
                if let Err(err) = network_block::apply(&view, true) {
                    eprintln!("Network block rules failed to install: {err}");
                }
            }
        }
        #[cfg(windows)]
        let downloads = windows_platform::configure(&view, self.proxy.clone())
            .map_err(|error| wry::Error::Io(std::io::Error::other(error.to_string())))?;
        #[cfg(not(windows))]
        let downloads = std::rc::Rc::new(std::cell::Cell::new(0));
        Ok(LivePage {
            allow_internal_navigation,
            pending_html_navigation,
            downloads,
            view,
            last_used: self.usage_clock,
            generation,
            loading: false,
        })
    }

    fn enforce_page_budget(&mut self) {
        if !self.data.auto_discard {
            return;
        }
        let active = self.active_id();
        while self.pages.len() > self.data.live_tab_budget as usize {
            let victim = lru_victim(
                self.pages
                    .iter()
                    .filter(|(_, page)| page.downloads.get() == 0)
                    .map(|(tab_id, page)| (*tab_id, page.last_used)),
                active,
            );
            if let Some(id) = victim {
                self.pages.remove(&id);
            } else {
                break;
            }
        }
    }

    // Keep only a bounded number of live WebViews. Cached tabs retain their DOM,
    // form state and scroll position. Evicted tabs keep URL/history and reload.
    fn show_active(&mut self) {
        let id = self.active_id();
        self.usage_clock = self.usage_clock.saturating_add(1);
        for (other_id, page) in &self.pages {
            if *other_id != id {
                let _ = page.view.set_visible(false);
                #[cfg(windows)]
                let _ = page.view.set_memory_usage_level(MemoryUsageLevel::Low);
            }
        }
        if !self.pages.contains_key(&id) {
            while self.data.auto_discard && self.pages.len() >= self.data.live_tab_budget as usize {
                let victim = lru_victim(
                    self.pages
                        .iter()
                        .filter(|(_, page)| page.downloads.get() == 0)
                        .map(|(tab_id, page)| (*tab_id, page.last_used)),
                    id,
                );
                if let Some(victim) = victim {
                    self.pages.remove(&victim);
                } else {
                    break;
                }
            }
            match self.make_view(id) {
                Ok(page) => {
                    self.pages.insert(id, page);
                    self.load_active();
                }
                Err(err) => self.notice(&format!("Не удалось создать WebView: {err}")),
            }
        }
        if let Some(page) = self.pages.get_mut(&id) {
            page.last_used = self.usage_clock;
            let _ = page.view.set_visible(!self.appearance_open);
            #[cfg(windows)]
            let _ = page.view.set_memory_usage_level(MemoryUsageLevel::Normal);
            let _ = page.view.focus();
            if self.data.customization.animations {
                let _ = page.view.evaluate_script("if(!matchMedia('(prefers-reduced-motion: reduce)').matches){document.documentElement.animate([{opacity:.72},{opacity:1}],{duration:150,easing:'ease-out'});}");
            }
        }
        self.sync_toolbar();
    }

    fn load_active(&mut self) {
        let url = self.current_url().to_owned();
        let html = match url.as_str() {
            NEW_TAB => Some(literust_browser::newtab::render(
                &self.data,
                self.private_mode,
            )),
            BOOKMARKS | HISTORY | DOWNLOADS => Some(render_library(&url, &self.data)),
            _ => None,
        };
        let html = html.map(|html| self.themed_html(html));
        let block_for_url = self.filter_enabled_for(&url);
        if let Some(page) = self.pages.get_mut(&self.active_id()) {
            // Adjust the CDP rule list before starting a toolbar-initiated navigation.
            // CDP completion is async: this is best-effort and not a security boundary.
            #[cfg(windows)]
            if let Err(err) = network_block::apply(&page.view, block_for_url) {
                eprintln!("Cannot apply per-site network rules: {err}");
            }
            #[cfg(not(windows))]
            let _ = block_for_url;
            page.loading = valid_web_url(&url);
            page.allow_internal_navigation.set(html.is_some());
            page.pending_html_navigation.set(html.is_some());
            let result = match html {
                Some(html) => page.view.load_html(&html),
                None => page.view.load_url(&url),
            };
            if let Err(err) = result {
                page.loading = false;
                eprintln!("Navigation failed: {err}");
            }
        }
        self.sync_toolbar();
    }

    fn navigate(&mut self, input: &str) {
        if security::reject_address_input(input) {
            self.notice(
                "Адрес отклонён: опасная схема, встроенные учётные данные или превышение длины.",
            );
            return;
        }
        let url =
            literust_browser::navigation::destination_with_engine(input, self.data.search_engine);
        self.navigate_internal(&url);
    }

    fn navigate_internal(&mut self, url: &str) {
        if !storage::valid_tab_url(url) {
            return;
        }
        if valid_web_url(url) && !security::safe_top_level_navigation(url) {
            self.notice("Опасный адрес: логин или пароль встроен прямо в URL. Переход отменён.");
            return;
        }
        if let Some(warning) = security::hostname_warning(url) {
            self.notice(warning);
        }
        self.data.tabs[self.data.active].navigate(url);
        self.load_active();
        self.persist();
    }

    fn open_library(&mut self, url: &str) {
        if let Some(index) = self.data.tabs.iter().position(|tab| tab.url == url) {
            self.data.active = index;
            self.show_active();
            self.load_active(); // Internal library pages are snapshots.
        } else if self.data.tabs.len() < MAX_TABS {
            self.new_tab(Some(url));
        } else {
            self.navigate_internal(url);
        }
        self.persist();
    }

    fn new_tab(&mut self, url: Option<&str>) {
        if self.data.tabs.len() >= MAX_TABS {
            self.notice("Достигнут лимит 24 вкладок.");
            return;
        }
        if let Some(url) = url {
            if valid_web_url(url) && !security::safe_top_level_navigation(url) {
                self.notice(
                    "Новая вкладка заблокирована: подозрительные данные пользователя в URL.",
                );
                return;
            }
        }
        let mut tab = match url {
            Some(url) if valid_web_url(url) => Tab::web(url),
            Some(url) if storage::valid_tab_url(url) => Tab::internal(url),
            _ => Tab::new(),
        };
        tab.id = self.next_tab_id;
        self.next_tab_id = self.next_tab_id.saturating_add(1);
        self.data.tabs.push(tab);
        self.data.active = self.data.tabs.len() - 1;
        self.show_active();
        self.persist();
    }

    fn handle(&mut self, command: UiCommand) {
        if self.appearance_open
            && matches!(
                &command,
                UiCommand::Home
                    | UiCommand::ShowBookmarks
                    | UiCommand::ShowHistory
                    | UiCommand::ShowDownloads
            )
        {
            let _ = self.toolbar.evaluate_script("window.openPanel?.(null);");
        }
        match command {
            UiCommand::ShowSettings | UiCommand::ShowAppearance | UiCommand::ShowVpn => {
                let panel = match command {
                    UiCommand::ShowVpn => "vpn",
                    UiCommand::ShowAppearance => "appearance",
                    _ => "settings",
                };
                let _ = self
                    .toolbar
                    .evaluate_script(&format!("window.openPanel?.('{panel}');"));
            }
            UiCommand::SetCustomIcon {
                target,
                value,
                rgba,
            } => {
                if self.private_mode {
                    self.notice("Меняйте значки в обычном окне.");
                    return;
                }
                if !literust_browser::icons::valid_target(&target)
                    || (!value.is_empty() && literust_browser::icons::png_bytes(&value).is_none())
                {
                    self.notice("Некорректный значок");
                    return;
                }
                if !value.is_empty()
                    && !self.data.custom_icons.contains_key(&target)
                    && self.data.custom_icons.len() >= 32
                {
                    self.notice("Можно сохранить до 32 своих значков.");
                    return;
                }
                if target == "app" {
                    use base64::Engine;
                    if !value.is_empty()
                        && !base64::engine::general_purpose::STANDARD
                            .decode(&rgba)
                            .is_ok_and(|v| v.len() == 64 * 64 * 4)
                    {
                        self.notice("Некорректный значок приложения");
                        return;
                    }
                    self.data.app_icon_rgba = rgba;
                }
                if value.is_empty() {
                    self.data.custom_icons.remove(&target);
                } else {
                    self.data.custom_icons.insert(target.clone(), value);
                }
                self.persist();
                self.sync_icons();
                if target == "app" {
                    self.update_app_icon();
                }
                if self.current_url() == NEW_TAB {
                    self.load_active();
                }
                self.notice("Значок сохранён");
            }
            UiCommand::SetCustomization { mut value } => {
                value.wallpaper_dim = value.wallpaper_dim.min(90);
                self.data.customization = value;
                self.persist();
                if self.current_url() == NEW_TAB {
                    self.load_active();
                }
                self.sync_toolbar();
            }
            UiCommand::SetBackground { value } => {
                if !literust_browser::newtab::valid_background(&value) {
                    self.notice("Выберите JPEG или HTTPS-ссылку на изображение.");
                    return;
                }
                self.data.background = value;
                self.persist();
                if self.current_url() == NEW_TAB {
                    self.load_active();
                }
                self.notice("Фон сохранён. Он появится на новой вкладке.");
            }
            UiCommand::SetSearchEngine { engine } => {
                self.data.search_engine = engine;
                self.persist();
                if self.current_url() == NEW_TAB {
                    self.load_active();
                }
                self.sync_toolbar();
            }
            UiCommand::SetDock { position } => {
                self.data.dock_position = position;
                self.resize();
                self.persist();
                self.sync_toolbar();
            }
            UiCommand::VpnProbe => {
                if !self.vpn_running || self.vpn_probing {
                    return;
                }
                if let Some(port) = self.vpn_port {
                    self.vpn_probing = true;
                    self.vpn_probe = "Проверяем HTTPS через VPN…".into();
                    self.sync_toolbar();
                    let proxy = self.proxy.clone();
                    std::thread::spawn(move || {
                        let result = vpn::probe(port);
                        let _ = proxy.send_event(AppEvent::VpnProbed(result));
                    });
                }
            }
            UiCommand::VpnScope { system } => {
                if self.private_mode || self.vpn_vault.enabled {
                    return;
                }
                self.vpn_vault.system_scope = system;
                #[cfg(windows)]
                if literust_browser::vpn_platform::save(&profile_root(), &self.vpn_vault).is_err() {
                    self.notice("Не удалось сохранить область VPN");
                }
                self.sync_toolbar();
            }
            UiCommand::VpnImport { value, kind } => {
                if self.private_mode || self.vpn_importing || self.vpn_vault.enabled {
                    self.notice("Импорт доступен в обычном окне при выключенном VPN.");
                    return;
                }
                if value.len() > vpn::MAX_IMPORT {
                    self.notice("Размер ключей превышает 1 MiB");
                    return;
                }
                self.vpn_importing = true;
                self.sync_toolbar();
                let proxy = self.proxy.clone();
                let port = self.vpn_port;
                std::thread::spawn(move || {
                    let result = vpn::import_with_kind(&value, port, kind);
                    let _ = proxy.send_event(AppEvent::VpnImported(result));
                });
            }
            UiCommand::VpnApply {
                enabled,
                selected,
                system,
            } => {
                if self.private_mode || self.vpn_importing {
                    self.notice("Изменение VPN доступно в обычном окне после завершения импорта");
                    return;
                }
                if enabled && selected >= self.vpn_vault.nodes.len() {
                    self.notice("Сначала импортируйте и выберите сервер");
                    return;
                }
                if self.pages.values().any(|p| p.downloads.get() > 0) {
                    self.notice("Дождитесь завершения скачиваний перед изменением VPN.");
                    return;
                }
                let previous = (
                    self.vpn_vault.enabled,
                    self.vpn_vault.selected,
                    self.vpn_vault.system_scope,
                );
                self.vpn_vault.system_scope = system;
                self.vpn_vault.enabled = enabled;
                self.vpn_vault.selected = selected;
                #[cfg(windows)]
                if literust_browser::vpn_platform::save(&profile_root(), &self.vpn_vault).is_err() {
                    (
                        self.vpn_vault.enabled,
                        self.vpn_vault.selected,
                        self.vpn_vault.system_scope,
                    ) = previous;
                    self.notice("Не удалось сохранить защищённые настройки VPN");
                    return;
                }
                #[cfg(not(windows))]
                {
                    let _ = previous;
                    self.notice("VPN-хаб поддерживается в Windows-сборке");
                    return;
                }
                #[cfg(windows)]
                {
                    self.restart_requested = true;
                }
            }
            UiCommand::GoogleAccountExternal => {
                if !self.private_mode && google_passwords::open_official_account().is_err() {
                    self.notice("Не удалось открыть системный браузер");
                }
            }
            UiCommand::Ready => {
                self.sync_icons();
                if !self.app_icon_applied && self.data.custom_icons.contains_key("app") {
                    self.app_icon_applied = true;
                    self.update_app_icon();
                }
                if self.vpn_vault.enabled
                    && self.vpn_vault.system_scope
                    && !self.system_vpn_running()
                    && !self.private_mode
                {
                    self.notice("VPN всего компьютера не запущен. Защищены только вкладки браузера. Откройте VPN-хаб и подтвердите запрос Windows.");
                }
                startup_log("Toolbar JavaScript ready");
                let _ = self.toolbar.set_visible(true);
                let _ = self.dock.set_visible(true);
                self.resize();
                self.window.request_redraw();
                self.sync_toolbar();
            }
            UiCommand::Navigate { value } => self.navigate(&value),
            UiCommand::Back => {
                if self.data.tabs[self.data.active].go_back() {
                    self.load_active();
                    self.persist();
                }
            }
            UiCommand::Forward => {
                if self.data.tabs[self.data.active].go_forward() {
                    self.load_active();
                    self.persist();
                }
            }
            UiCommand::Reload => {
                if !valid_web_url(self.current_url()) {
                    self.load_active();
                } else if let Some(page) = self.pages.get(&self.active_id()) {
                    if let Err(err) = page.view.reload() {
                        eprintln!("Reload: {err}");
                    }
                }
            }
            UiCommand::Home => self.navigate_internal(NEW_TAB),
            UiCommand::NewTab => self.new_tab(None),
            UiCommand::SelectTab { index } => {
                if index < self.data.tabs.len() && index != self.data.active {
                    self.data.active = index;
                    self.show_active();
                    self.persist();
                }
            }
            UiCommand::CloseTab { index } => {
                if index >= self.data.tabs.len() {
                    return;
                }
                let closed_id = self.data.tabs[index].id;
                if self
                    .pages
                    .get(&closed_id)
                    .is_some_and(|page| page.downloads.get() > 0)
                {
                    self.notice(
                        "Сначала завершите или отмените загрузку в стандартном окне загрузок.",
                    );
                    return;
                }
                let closed_active = index == self.data.active;
                self.pages.remove(&closed_id);
                self.data.tabs.remove(index);
                if self.data.tabs.is_empty() {
                    let mut tab = Tab::new();
                    tab.id = self.next_tab_id;
                    self.next_tab_id = self.next_tab_id.saturating_add(1);
                    self.data.tabs.push(tab);
                    self.data.active = 0;
                } else if closed_active {
                    self.data.active = index.min(self.data.tabs.len() - 1);
                } else if index < self.data.active {
                    self.data.active -= 1;
                }
                self.show_active();
                self.persist();
            }
            UiCommand::ToggleBookmark => {
                if self.private_mode {
                    self.notice("В приватном окне закладки не записываются на диск.");
                    return;
                }
                let tab = &self.data.tabs[self.data.active];
                let (url, title) = (tab.url.clone(), tab.title.clone());
                if !self.data.bookmarked(&url)
                    && self.data.bookmarks.len() >= storage::MAX_BOOKMARKS
                {
                    self.notice(
                        "Достигнут лимит закладок. Удалите ненужную закладку перед добавлением.",
                    );
                    return;
                }
                self.data.toggle_bookmark(&url, &title);
                self.persist();
                if self.current_url() == BOOKMARKS {
                    self.load_active();
                } else {
                    self.sync_toolbar();
                }
            }
            UiCommand::ShowBookmarks => self.open_library(BOOKMARKS),
            UiCommand::ShowHistory => self.open_library(HISTORY),
            UiCommand::ShowDownloads => self.open_library(DOWNLOADS),
            UiCommand::ExportBookmarks => {
                if self.private_mode {
                    self.notice("Экспорт закладок недоступен в приватном окне.");
                } else if self.data.bookmarks.is_empty() {
                    self.notice("Нет закладок для экспорта.");
                } else {
                    match export_bookmarks(&self.data) {
                        Ok(path) => self.notice(&format!(
                            "Экспортировано {} закладок: {}",
                            self.data.bookmarks.len(),
                            path.display()
                        )),
                        Err(err) => {
                            self.notice(&format!("Не удалось экспортировать закладки: {err}"))
                        }
                    }
                }
            }
            UiCommand::ClearDownloadHistory => {
                self.data.downloads.clear();
                self.persist();
                if self.current_url() == DOWNLOADS {
                    self.load_active();
                } else {
                    self.sync_toolbar();
                }
                self.notice("Список загрузок очищен. Скачанные файлы на диске НЕ удалены.");
            }
            UiCommand::ClearHistory => {
                self.data.history.clear();
                for tab in &mut self.data.tabs {
                    tab.back.clear();
                    tab.forward.clear();
                }
                self.persist();
                if self.current_url() == HISTORY {
                    self.load_active();
                } else {
                    self.sync_toolbar();
                }
                self.notice("История LiteRust удалена. Cookies и кэш не затронуты.");
            }
            UiCommand::ImportBookmarks { html } => {
                if self.private_mode {
                    self.notice("Импорт закладок недоступен в приватном окне.");
                    return;
                }
                match import::import_bookmarks(&mut self.data, &html) {
                    Ok(stats) => {
                        self.persist();
                        if self.current_url() == BOOKMARKS {
                            self.load_active();
                        } else {
                            self.sync_toolbar();
                        }
                        self.notice(&format!(
                            "Импорт завершён: +{} закладок, {} повторов, {} неподдерживаемых, {} сверх лимита.",
                            stats.added, stats.duplicates, stats.rejected, stats.skipped_capacity,
                        ));
                    }
                    Err(err) => self.notice(err),
                }
            }
            UiCommand::AppearancePanel { open } => {
                self.appearance_open = open;
                for (id, page) in &self.pages {
                    let _ = page.view.set_visible(!open && *id == self.active_id());
                }
                self.resize();
            }
            UiCommand::SetAppearance { design, theme } => {
                if design >= 5 || theme >= 55 {
                    return;
                }
                self.data.appearance = storage::Appearance { design, theme };
                self.persist();
                self.sync_toolbar();
                let settings = serde_json::to_string(&self.data.appearance).unwrap_or_default();
                for (id, page) in &self.pages {
                    if self
                        .data
                        .tabs
                        .iter()
                        .any(|t| t.id == *id && t.url.starts_with("literust://"))
                    {
                        let _ = page
                            .view
                            .evaluate_script(&format!("window.applyAppearance?.({settings});"));
                    }
                }
            }
            UiCommand::DiscardBackground => {
                let active = self.active_id();
                let before = self.pages.len();
                self.pages
                    .retain(|id, page| *id == active || page.loading || page.downloads.get() > 0);
                self.sync_toolbar();
                self.notice(&format!("Выгружено вкладок: {}. Активная вкладка, загружающиеся страницы и скачивания сохранены.", before - self.pages.len()));
            }
            UiCommand::OpenGoogleAccount => {
                if self.private_mode {
                    self.notice("Для постоянного входа откройте Google в обычном окне LiteRust.");
                    return;
                }
                if let Some(index) = self.data.tabs.iter().position(|t| {
                    url::Url::parse(&t.url).ok().is_some_and(|u| {
                        matches!(
                            u.host_str(),
                            Some("myaccount.google.com" | "accounts.google.com")
                        )
                    })
                }) {
                    self.data.active = index;
                    self.show_active();
                } else if self.data.tabs.len() < MAX_TABS {
                    self.new_tab(Some(google_passwords::OFFICIAL_ACCOUNT_URL));
                } else {
                    self.navigate_internal(google_passwords::OFFICIAL_ACCOUNT_URL);
                }
                self.persist();
            }
            UiCommand::OpenGooglePasswords => {
                if self.private_mode {
                    self.notice("Google Password Manager открывается во внешнем обычном браузере. В приватном окне LiteRust действие отключено.");
                    return;
                }
                match google_passwords::open_official_manager() {
                    Ok(()) => self.notice("Открываем Google Password Manager во внешнем браузере. Автозаполнение Google внутри LiteRust пока недоступно."),
                    Err(err) => self.notice(&format!("Не удалось открыть Google Password Manager: {err}")),
                }
            }
            UiCommand::ClearSiteData => {
                if let Some(page) = self.pages.get(&self.active_id()) {
                    match page.view.clear_all_browsing_data() {
                        Ok(()) => self.notice(
                            "Запрошена очистка всех данных сайтов WebView2, включая cookies и кэш.",
                        ),
                        Err(err) => {
                            self.notice(&format!("Не удалось очистить данные сайтов: {err}"))
                        }
                    }
                }
            }
            UiCommand::NewPrivateWindow => {
                match std::env::current_exe().and_then(|exe| Command::new(exe).arg("--private").spawn()) {
                    Ok(_) => self.notice("Открыто отдельное приватное окно. Файлы загрузок всё равно сохраняются на диск."),
                    Err(err) => self.notice(&format!("Не удалось открыть приватное окно: {err}")),
                }
            }
            UiCommand::ToggleNetworkBlocking => {
                self.data.network_blocking = !self.data.network_blocking;
                self.update_filter_for_live_pages();
                self.persist();
                self.sync_toolbar();
                if valid_web_url(self.current_url()) {
                    if let Some(page) = self.pages.get(&self.active_id()) {
                        if let Err(err) = page.view.reload() {
                            eprintln!("Filter reload: {err}");
                        }
                    }
                }
                self.notice(if self.data.network_blocking {
                    "Экспериментальный сетевой фильтр включён. Блокирует ограниченный список рекламных хостов, некоторые сайты могут работать неправильно."
                } else {
                    "Сетевой фильтр выключен. Правила отменены, активная страница обновлена."
                });
            }
            UiCommand::ToggleAutoDiscard => {
                self.data.auto_discard = !self.data.auto_discard;
                self.enforce_page_budget();
                self.persist();
                self.sync_toolbar();
            }
            UiCommand::CycleMemoryMode => {
                let budget = self.data.cycle_live_tab_budget();
                self.enforce_page_budget();
                self.persist();
                self.sync_toolbar();
                self.notice(&format!("Бюджет: {budget}. Он применяется только при включённой автовыгрузке; формы и медиа при выгрузке теряются."));
            }
            UiCommand::ToggleSiteAdblock => {
                let url = self.current_url().to_owned();
                if !self.data.network_blocking {
                    self.notice(
                        "Включите сетевой AdBlock, чтобы управлять исключениями для сайтов.",
                    );
                    return;
                }
                let Some(host) = storage::site_host(&url) else {
                    self.notice("Исключение доступно только для открытого HTTP(S)-сайта.");
                    return;
                };
                match self.data.toggle_adblock_exception(&url) {
                    Some(is_excepted) => {
                        self.update_filter_for_live_pages();
                        self.persist();
                        self.sync_toolbar();
                        if let Some(page) = self.pages.get(&self.active_id()) {
                            if let Err(err) = page.view.reload() {
                                eprintln!("Filter reload: {err}");
                            }
                        }
                        self.notice(&format!(
                            "Сетевой AdBlock для {host}: {}. Активная страница обновлена.",
                            if is_excepted {
                                "выключен"
                            } else {
                                "включён"
                            },
                        ));
                    }
                    None => self.notice(
                        "Не удалось изменить исключение (возможно, достигнут лимит 256 сайтов).",
                    ),
                }
            }
            UiCommand::ToggleCosmeticFilter => {
                if self.pages.values().any(|page| page.downloads.get() > 0) {
                    self.notice("Дождитесь завершения загрузок перед пересозданием вкладок.");
                    return;
                }
                self.data.cosmetic_filter = !self.data.cosmetic_filter;
                // Initialization scripts are fixed at WebView construction time.
                // Rebuild all live WebViews for reliable toggle semantics.
                self.pages.clear();
                self.show_active();
                self.persist();
                self.notice("Косметический фильтр переключён. Вкладки перезагрузятся. Он скрывает часть баннеров, но НЕ блокирует рекламные запросы.");
            }
        }
    }

    fn matching_view(&self, tab_id: u64, generation: u64) -> bool {
        self.pages
            .get(&tab_id)
            .is_some_and(|p| p.generation == generation)
    }

    fn on_page_event(&mut self, tab_id: u64, generation: u64, url: String, loading: bool) {
        if !self.matching_view(tab_id, generation) {
            return;
        }
        // Initial NavigateToString callbacks can arrive after load_url. They
        // must not mark the later network navigation as finished.
        if url == "about:blank"
            && self
                .pages
                .get(&tab_id)
                .is_some_and(|p| !p.allow_internal_navigation.get())
        {
            return;
        }
        let enabled_for_url = self.filter_enabled_for(&url);
        if let Some(page) = self.pages.get_mut(&tab_id) {
            page.loading = loading;
            // Handles in-page/cross-site navigation and redirects, possibly after
            // the first request. Do not present this as comprehensive blocking.
            #[cfg(windows)]
            if loading {
                if let Err(err) = network_block::apply(&page.view, enabled_for_url) {
                    eprintln!("Cannot adjust filter on page load: {err}");
                }
            }
            #[cfg(not(windows))]
            let _ = enabled_for_url;
        }
        if valid_web_url(&url) {
            let title = self
                .data
                .tabs
                .iter_mut()
                .find(|tab| tab.id == tab_id)
                .map(|tab| {
                    if tab.url != url {
                        tab.navigate(&url);
                    }
                    tab.title.clone()
                });
            if !loading && !self.private_mode {
                if let Some(title) = title {
                    self.data.record_visit(&url, &title);
                }
            }
        }
        if !loading {
            self.persist();
        }
        if self.active_id() == tab_id {
            self.sync_toolbar();
        }
    }

    fn on_title(&mut self, tab_id: u64, generation: u64, title: String) {
        if !self.matching_view(tab_id, generation) {
            return;
        }
        let title = storage::compact_title(title.trim());
        if title.is_empty() {
            return;
        }
        if let Some(tab) = self
            .data
            .tabs
            .iter_mut()
            .find(|tab| tab.id == tab_id && valid_web_url(&tab.url))
        {
            tab.title = title.clone();
            let url = tab.url.clone();
            if let Some(entry) = self.data.history.iter_mut().rev().find(|h| h.url == url) {
                entry.title = title;
            }
            self.persist();
            if self.active_id() == tab_id {
                self.sync_toolbar();
            }
        }
    }

    fn on_download_start(&mut self, id: u64, url: String, file: String) {
        self.data.record_download_start(id, url, file);
        self.persist();
        self.sync_toolbar();
    }
    fn on_download_state(&mut self, id: u64, file: &Path, running: bool, ok: bool) {
        self.data.record_download_state(id, file, running, ok);
        self.persist();
        if self.current_url() == DOWNLOADS {
            self.load_active();
        } else {
            self.sync_toolbar();
        }
    }

    fn resize(&self) {
        let size = self
            .window
            .inner_size()
            .to_logical::<f64>(self.window.scale_factor());
        let _ = self
            .toolbar
            .set_bounds(rect(0.0, 0.0, size.width, self.toolbar_height()));
        let (dock_bounds, bounds) = self.layout_bounds();
        let _ = self.dock.set_bounds(dock_bounds);
        for page in self.pages.values() {
            let _ = page.view.set_bounds(bounds);
        }
    }
}

/// Do not grant top-level access to file:// or executable URL schemes.
fn permitted_page_navigation(url: &str) -> bool {
    security::safe_top_level_navigation(url) && (valid_web_url(url) || url == "about:blank")
}

/// Explicitly ask on sensitive permissions, deny silent high-risk API access.
/// The native WebView2 permission prompt is used; no fake permission UI.
fn site_permission_policy(kind: PermissionKind) -> PermissionResponse {
    match kind {
        PermissionKind::Camera
        | PermissionKind::Microphone
        | PermissionKind::Geolocation
        | PermissionKind::DisplayCapture => PermissionResponse::Default,
        PermissionKind::Notifications
        | PermissionKind::ClipboardRead
        | PermissionKind::Midi
        | PermissionKind::Sensors
        | PermissionKind::AutomaticDownloads
        | PermissionKind::FileSystemAccess => PermissionResponse::Deny,
        PermissionKind::Autoplay => PermissionResponse::Default,
        _ => PermissionResponse::Deny,
    }
}

fn library_row(href: &str, title: &str, subtitle: &str, badge: &str) -> String {
    let label = if title.is_empty() { href } else { title };
    format!(
        "<a class=\"entry\" href=\"{}\" title=\"{}\"><span class=\"entry-text\"><strong>{}</strong><small>{}</small></span><span class=\"tag\">{}</span></a>",
        escape_html(href), escape_html(href), escape_html(label),
        escape_html(subtitle), escape_html(badge)
    )
}

fn render_library(kind: &str, data: &BrowserData) -> String {
    let (title, lead, entries): (&str, &str, Vec<String>) = match kind {
        BOOKMARKS => ("Закладки", "Избранные сайты. Звёздочка в адресной строке добавляет или удаляет закладку.",
            data.bookmarks.iter().rev().map(|b| library_row(&b.url, &b.title, &b.url, "★")).collect()),
        HISTORY => ("История", "Сохранённые посещения (до 1500). Историю можно очистить через меню ⋯ вверху.",
            data.history.iter().rev().map(|h| library_row(&h.url, &h.title, &h.url, "↗")).collect()),
        DOWNLOADS => ("Загрузки", "Список загрузок. Файлы сохраняет движок WebView2; здесь отображается их статус.",
            data.downloads.iter().rev().take(150).map(|d| {
                // This page must not expose local file:// links or paths as hrefs.
                format!("<div class=\"entry\"><span class=\"entry-text\"><strong>{}</strong><small>{}</small></span><span class=\"tag\">{}</span></div>",
                    escape_html(d.file.rsplit(['\\', '/']).next().unwrap_or(&d.file)),
                    escape_html(&d.url), escape_html(&d.status))
            }).collect()),
        _ => ("LiteRust", "", vec![]),
    };
    let content = if entries.is_empty() {
        "<div class=\"empty\">Здесь пока ничего нет</div>".into()
    } else {
        entries.join("\n")
    };
    LIBRARY
        .replace("__TITLE__", title)
        .replace("__LEAD__", lead)
        .replace("<!-- ENTRIES -->", &content)
}

fn rect(x: f64, y: f64, width: f64, height: f64) -> Rect {
    Rect {
        position: LogicalPosition::new(x, y).into(),
        size: WebLogicalSize::new(width.max(1.0), height.max(1.0)).into(),
    }
}

/// Export a Chrome-compatible Netscape bookmarks HTML file. Only browser
/// metadata is exported; passwords and cookies are never touched.
fn export_bookmarks(data: &BrowserData) -> std::io::Result<PathBuf> {
    let downloads = std::env::var_os("USERPROFILE")
        .map(|home| PathBuf::from(home).join("Downloads"))
        .filter(|path| path.is_dir());
    let dir = downloads.unwrap_or_else(|| profile_root().join("Exports"));
    fs::create_dir_all(&dir)?;
    let stamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_secs());
    let content = data.bookmarks_as_html();
    // create_new is intentional: exports never silently replace an older file.
    for suffix in 0..100u32 {
        let name = if suffix == 0 {
            format!("literust-bookmarks-{stamp}.html")
        } else {
            format!("literust-bookmarks-{stamp}-{suffix}.html")
        };
        let path = dir.join(name);
        match fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
        {
            Ok(mut file) => {
                if let Err(err) = file
                    .write_all(content.as_bytes())
                    .and_then(|_| file.sync_all())
                {
                    drop(file);
                    let _ = fs::remove_file(&path);
                    return Err(err);
                }
                return Ok(path);
            }
            Err(err) if err.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(err) => return Err(err),
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::AlreadyExists,
        "слишком много файлов экспорта за секунду",
    ))
}

fn profile_root() -> PathBuf {
    std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .or_else(|| {
            std::env::var_os("USERPROFILE")
                .map(|home| PathBuf::from(home).join("AppData").join("Local"))
        })
        .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")))
        .join("LiteRustBrowser")
}

fn startup_log(message: &str) {
    let file = profile_root().join("diagnostics").join("startup.log");
    if let Ok(mut file) = fs::OpenOptions::new().create(true).append(true).open(file) {
        let _ = writeln!(file, "{message}");
    }
}

fn main() {
    // Do this before spawning threads or creating WebView2 environments.
    for key in [
        "WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS",
        "WEBVIEW2_BROWSER_EXECUTABLE_FOLDER",
        "WEBVIEW2_USER_DATA_FOLDER",
        "WEBVIEW2_PIPE_FOR_SCRIPT_DEBUGGER",
    ] {
        std::env::remove_var(key);
    }
    #[cfg(windows)]
    if std::env::args().any(|arg| arg == "--tun-self-test") {
        let result = literust_browser::system_vpn::self_test();
        let log = std::env::current_exe()
            .unwrap()
            .with_file_name("tun-self-test.log");
        let _ = fs::write(
            log,
            match &result {
                Ok(_) => "PASS: Windows TUN to SOCKS fixture and owned cleanup".to_string(),
                Err(e) => format!("FAIL: {e}"),
            },
        );
        std::process::exit(if result.is_ok() { 0 } else { 1 });
    }

    #[cfg(windows)]
    if std::env::args().any(|arg| arg == "--check-runtime") {
        std::process::exit(
            if wry::webview_version().is_ok_and(|version| !version.trim().is_empty()) {
                0
            } else {
                1
            },
        );
    }

    let diagnostics = profile_root().join("diagnostics");
    if fs::create_dir_all(&diagnostics).is_ok() {
        let _ = fs::write(
            diagnostics.join("startup.log"),
            b"LiteRust 0.13.0-alpha.2 startup\n",
        );
    }
    if let Err(error) = run() {
        startup_log(&format!("Startup failed: {error}"));
        #[cfg(windows)]
        unsafe {
            use windows::{
                core::HSTRING,
                Win32::UI::WindowsAndMessaging::{MessageBoxW, MB_ICONERROR, MB_OK},
            };
            let message = HSTRING::from(format!("LiteRust не удалось запустить: {error}"));
            MessageBoxW(
                None,
                &message,
                &HSTRING::from("LiteRust — ошибка запуска"),
                MB_OK | MB_ICONERROR,
            );
        }
        #[cfg(not(windows))]
        eprintln!("LiteRust startup failed: {error}");
        std::process::exit(1);
    }
}

fn run() -> Result<(), Box<dyn std::error::Error>> {
    let private_mode = std::env::args().any(|arg| arg == "--private");
    // Fail before creating any native window: an absent runtime must not leave
    // a blank window while WebView construction is attempted.
    #[cfg(windows)]
    {
        startup_log("Checking WebView2 Runtime");
        let version = wry::webview_version().map_err(|error| {
            std::io::Error::other(format!(
                "Microsoft Edge WebView2 Runtime не найден или недоступен.\n\nУстановите WebView2 Runtime с официального сайта Microsoft:\nhttps://go.microsoft.com/fwlink/p/?LinkId=2124703\n\nПосле установки снова запустите LiteRust. Сам браузер Edge устанавливать не обязательно.\n\nДиагностика: {error}"
            ))
        })?;
        if version.trim().is_empty() {
            return Err(std::io::Error::other("WebView2 вернул пустую версию. Установите Microsoft WebView2 Runtime: https://go.microsoft.com/fwlink/p/?LinkId=2124703").into());
        }
        startup_log(&format!("WebView2 Runtime available: {version}"));
    }
    startup_log("Creating event loop and window");
    let event_loop = EventLoopBuilder::<AppEvent>::with_user_event().build();
    let window = WindowBuilder::new()
        .with_visible(false)
        .with_window_icon(
            tao::window::Icon::from_rgba(
                include_bytes!("../packaging/default-icon.rgba").to_vec(),
                64,
                64,
            )
            .ok(),
        )
        .with_title(if private_mode {
            "LiteRust 0.13-alpha.2 — приватное окно"
        } else {
            "LiteRust Browser 0.13-alpha.2"
        })
        .with_inner_size(LogicalSize::new(1280.0, 800.0))
        .with_min_inner_size(LogicalSize::new(690.0, 400.0))
        .build(&event_loop)?;

    let _profile_lock = if private_mode {
        None
    } else {
        Some({
            let mut lock = profile::ProfileLock::acquire(&profile_root());
            if std::env::args().any(|a| a == "--resume-after-restart") {
                for _ in 0..40 {
                    if lock.is_ok() {
                        break;
                    }
                    std::thread::sleep(std::time::Duration::from_millis(250));
                    lock = profile::ProfileLock::acquire(&profile_root());
                }
            }
            lock?
        })
    };
    let (data, data_file, context) = if private_mode {
        // No normal profile opened and no browser-data.json read/written.
        (BrowserData::default().clean(), None, None)
    } else {
        let root = profile_root();
        fs::create_dir_all(&root)?;
        let file = root.join("browser-data.json");
        let data = BrowserData::load(&file)?;
        data.save(&file)?; // migrate plaintext metadata before opening site views
        (
            data,
            Some(file),
            Some(WebContext::new(Some(root.join("WebView2")))),
        )
    };
    #[cfg(windows)]
    let mut vpn_vault = literust_browser::vpn_platform::load(&profile_root())?;
    #[cfg(windows)]
    if private_mode {
        vpn_vault.system_scope = false;
    }
    #[cfg(not(windows))]
    let vpn_vault = vpn::Vault::default();
    #[cfg(windows)]
    if std::env::args().any(|a| a == "--vpn-off") {
        vpn_vault.enabled = false;
        if !private_mode {
            literust_browser::vpn_platform::save(&profile_root(), &vpn_vault)?;
        }
    }
    #[cfg(windows)]
    let vpn_tunnel = if vpn_vault.enabled {
        Some(literust_browser::vpn_platform::Tunnel::start(&vpn_vault).map_err(|_|std::io::Error::other("VPN не запустился. Прямое соединение не включено. Запустите LiteRust с --vpn-off, чтобы изменить ключ."))?)
    } else {
        None
    };
    #[cfg(windows)]
    let vpn_port = vpn_tunnel.as_ref().map(|t| t.port);
    #[cfg(windows)]
    let system_vpn = if vpn_vault.enabled && vpn_vault.system_scope && !private_mode {
        let result = literust_browser::system_vpn::SystemTunnel::start(
            vpn_tunnel.as_ref().unwrap().socks_port,
        );
        if result.is_err() {
            startup_log("System VPN unavailable; browser remains proxied");
        }
        result.ok()
    } else {
        None
    };
    #[cfg(not(windows))]
    let vpn_port: Option<u16> = None;
    let size = window.inner_size().to_logical::<f64>(window.scale_factor());
    let toolbar_proxy = event_loop.create_proxy();
    startup_log("Creating toolbar WebView");
    let mut ui_context = WebContext::new(Some(profile_root().join("Interface-v2")));
    let toolbar_builder = if private_mode {
        WebViewBuilder::new()
    } else {
        WebViewBuilder::new_with_web_context(&mut ui_context)
    };
    let toolbar_initial_document = std::cell::Cell::new(true);
    let toolbar = routed_builder(toolbar_builder, vpn_port)
        .with_incognito(private_mode)
        .with_permission_handler(|_| PermissionResponse::Deny)
        .with_html(security::control_document(
            &TOOLBAR.replace("/* APPEARANCE_SCRIPT */", APPEARANCE_SCRIPT),
        )?)
        .with_bounds(rect(0.0, 0.0, size.width, TOOLBAR_HEIGHT))
        .with_navigation_handler(move |_url| {
            let allowed = toolbar_initial_document.replace(false);
            startup_log(if allowed {
                "Interface navigation allowed"
            } else {
                "Interface navigation rejected"
            });
            allowed
        })
        .with_on_page_load_handler(|event, _| {
            startup_log(if matches!(event, PageLoadEvent::Finished) {
                "Interface document finished"
            } else {
                "Interface document loading"
            })
        })
        .with_new_window_req_handler(|_, _| NewWindowResponse::Deny)
        .with_ipc_handler(move |request| {
            if request.uri() == "about:blank" && request.body().len() <= 2_100_000 {
                if let Ok(command) = serde_json::from_str::<UiCommand>(request.body()) {
                    if matches!(command, UiCommand::Ready) {
                        startup_log("Main toolbar IPC ready");
                    }
                    let _ = toolbar_proxy.send_event(AppEvent::Ui(command));
                }
            }
        })
        .build_as_child(&window)?;

    let dock_proxy = event_loop.create_proxy();
    let dock_builder = if private_mode {
        WebViewBuilder::new()
    } else {
        WebViewBuilder::new_with_web_context(&mut ui_context)
    };
    let dock_initial_document = std::cell::Cell::new(true);
    let dock = routed_builder(dock_builder, vpn_port)
        .with_incognito(private_mode)
        .with_permission_handler(|_| PermissionResponse::Deny)
        .with_html(security::control_document(
            &DOCK.replace("/* APPEARANCE_SCRIPT */", APPEARANCE_SCRIPT),
        )?)
        .with_bounds(rect(
            0.0,
            TOOLBAR_HEIGHT,
            54.0,
            (size.height - TOOLBAR_HEIGHT).max(1.0),
        ))
        .with_navigation_handler(move |_url| {
            let allowed = dock_initial_document.replace(false);
            startup_log(if allowed {
                "Interface navigation allowed"
            } else {
                "Interface navigation rejected"
            });
            allowed
        })
        .with_on_page_load_handler(|event, _| {
            startup_log(if matches!(event, PageLoadEvent::Finished) {
                "Interface document finished"
            } else {
                "Interface document loading"
            })
        })
        .with_new_window_req_handler(|_, _| NewWindowResponse::Deny)
        .with_ipc_handler(move |request| {
            if request.uri() == "about:blank" && request.body().len() < 1024 {
                if let Ok(command) = serde_json::from_str::<UiCommand>(request.body()) {
                    // The dock only needs fixed navigation/settings actions.
                    if matches!(
                        command,
                        UiCommand::Ready
                            | UiCommand::Home
                            | UiCommand::ShowSettings
                            | UiCommand::ShowAppearance
                            | UiCommand::ShowVpn
                            | UiCommand::ShowBookmarks
                            | UiCommand::ShowHistory
                            | UiCommand::ShowDownloads
                            | UiCommand::DiscardBackground
                    ) {
                        let _ = dock_proxy.send_event(AppEvent::Ui(command));
                    }
                }
            }
        })
        .build_as_child(&window)?;
    let mut browser = Browser::new(
        window,
        toolbar,
        dock,
        context,
        data,
        data_file,
        event_loop.create_proxy(),
        private_mode,
    );
    browser.vpn_vault = vpn_vault;
    browser.vpn_port = vpn_port;
    browser.vpn_running = vpn_port.is_some();
    #[cfg(windows)]
    {
        browser.vpn_tunnel = vpn_tunnel;
        browser.system_vpn = system_vpn;
    }
    browser.resize();
    startup_log("Toolbar WebView created; creating active page");
    browser.show_active();
    browser.window.set_visible(true);
    startup_log("Entering event loop");

    event_loop.run(move |event, _, control_flow| {
        *control_flow = if browser.vpn_port.is_some() { ControlFlow::WaitUntil(std::time::Instant::now()+std::time::Duration::from_secs(2)) } else { ControlFlow::Wait };
        #[cfg(windows)]
        if browser.vpn_running && browser.vpn_tunnel.as_mut().is_some_and(|t|!t.alive()) {
            browser.vpn_running=false;browser.sync_toolbar();
            browser.notice("VPN остановился. Прямое соединение не включается. Откройте VPN-хаб.");
        }
        #[cfg(windows)]
        if browser.system_vpn.as_ref().is_some_and(|t|!t.alive()) {
            browser.system_vpn.take();browser.sync_toolbar();browser.notice("VPN всего ПК остановлен. Windows может использовать обычную сеть. Браузер остаётся на своём прокси.");
        }
        match event {
            Event::UserEvent(AppEvent::Ui(cmd)) => browser.handle(cmd),
            Event::UserEvent(AppEvent::NewTabAppearance {tab_id,generation}) => {
                if browser.matching_view(tab_id,generation) && browser.data.tabs.iter().any(|t|t.id==tab_id&&t.url==NEW_TAB) {
                    browser.handle(UiCommand::ShowSettings);
                }
            },
            Event::UserEvent(AppEvent::VpnProbed(result)) => {
                browser.vpn_probing=false;
                browser.vpn_probe=if !browser.vpn_running {"VPN остановился".into()} else {match result {Ok(ms)=>format!("HTTPS через VPN: {ms} мс"),Err(message)=>message.into()}};
                browser.sync_toolbar();
            }
            Event::UserEvent(AppEvent::VpnImported(result)) => {
                browser.vpn_importing=false;
                match result {
                    Ok(nodes)=>{
                        let system_scope=browser.vpn_vault.system_scope;
                        let previous=std::mem::replace(&mut browser.vpn_vault,vpn::Vault{nodes,enabled:false,selected:0,system_scope});
                        #[cfg(windows)]
                        if literust_browser::vpn_platform::save(&profile_root(),&browser.vpn_vault).is_err(){browser.vpn_vault=previous;browser.notice("Не удалось сохранить VPN-ключи");}
                        else {browser.notice("Серверы импортированы и защищены учётной записью Windows. Выберите сервер и подключитесь.");}
                        #[cfg(not(windows))]
                        {browser.vpn_vault=previous;browser.notice("VPN-хаб доступен в Windows-сборке");}
                    },
                    Err(message)=>browser.notice(message),
                }
                browser.sync_toolbar();
            },
            Event::UserEvent(AppEvent::Page {
                tab_id,
                generation,
                url,
                loading,
            }) => {
                browser.on_page_event(tab_id, generation, url, loading);
            }
            Event::UserEvent(AppEvent::Title {
                tab_id,
                generation,
                title,
            }) => {
                browser.on_title(tab_id, generation, title);
            }
            Event::UserEvent(AppEvent::Popup {
                tab_id,
                generation,
                url,
            }) => {
                if browser.matching_view(tab_id, generation) {
                    browser.new_tab(Some(&url));
                }
            }
            Event::UserEvent(AppEvent::DownloadStarted { id, url, file }) => {
                browser.on_download_start(id, url, file)
            }
            Event::UserEvent(AppEvent::DownloadState {
                id,
                file,
                running,
                ok,
            }) => browser.on_download_state(id, &file, running, ok),
            Event::WindowEvent {
                event: WindowEvent::Resized(_),
                ..
            }
            | Event::WindowEvent {
                event: WindowEvent::ScaleFactorChanged { .. },
                ..
            } => browser.resize(),
            Event::WindowEvent {
                event: WindowEvent::CloseRequested,
                ..
            } => {
                browser.persist();
                #[cfg(windows)]
                { browser.system_vpn.take(); browser.vpn_tunnel.take(); }
                *control_flow = ControlFlow::Exit;
            }
            _ => {}
        }
        if browser.restart_requested {
            browser.restart_requested=false;
            browser.persist();
            match std::env::current_exe().and_then(|exe|Command::new(exe).arg("--resume-after-restart").spawn()) {
                Ok(_)=>{
                    #[cfg(windows)]
                    { browser.system_vpn.take(); browser.vpn_tunnel.take(); }
                    *control_flow=ControlFlow::Exit;
                },
                Err(_)=>browser.notice("Настройки VPN сохранены. Закройте и заново запустите LiteRust для применения."),
            }
        }
    });
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn lru_never_evicts_active_tab() {
        let entries = vec![(10, 7), (20, 1), (30, 4)];
        assert_eq!(lru_victim(entries.clone(), 10), Some(20));
        assert_eq!(lru_victim(entries, 20), Some(30));
        assert_eq!(lru_victim([(10, 7)], 10), None);
    }
    #[test]
    fn google_manager_command_is_explicitly_opt_in() {
        assert!(matches!(
            serde_json::from_str::<UiCommand>(r#"{"action":"open_google_passwords"}"#),
            Ok(UiCommand::OpenGooglePasswords)
        ));
    }
    #[test]
    fn memory_mode_command_is_supported() {
        assert!(matches!(
            serde_json::from_str::<UiCommand>(r#"{"action":"cycle_memory_mode"}"#),
            Ok(UiCommand::CycleMemoryMode)
        ));
    }
    #[test]
    fn bookmark_export_and_download_cleanup_commands_are_supported() {
        assert!(matches!(
            serde_json::from_str::<UiCommand>(r#"{"action":"export_bookmarks"}"#),
            Ok(UiCommand::ExportBookmarks)
        ));
        assert!(matches!(
            serde_json::from_str::<UiCommand>(r#"{"action":"clear_download_history"}"#),
            Ok(UiCommand::ClearDownloadHistory)
        ));
    }
    #[test]
    fn site_adblock_toggle_command_is_supported() {
        assert!(matches!(
            serde_json::from_str::<UiCommand>(r#"{"action":"toggle_site_adblock"}"#),
            Ok(UiCommand::ToggleSiteAdblock)
        ));
    }
    #[test]
    fn input_search_or_url() {
        assert_eq!(destination("   "), NEW_TAB);
        assert_eq!(
            destination("https://example.com/a"),
            "https://example.com/a"
        );
        assert_eq!(destination("example.org"), "https://example.org/");
        assert_eq!(destination("localhost:8080"), "http://localhost:8080/");
        assert!(
            destination("mailto:test@example.com").starts_with("https://www.google.com/search?")
        );
        assert!(destination("javascript:alert(1)").starts_with("https://www.google.com/search?"));
        assert_eq!(destination("как работает Rust"), "https://www.google.com/search?q=%D0%BA%D0%B0%D0%BA+%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%B5%D1%82+Rust");
    }
    #[test]
    fn block_untrusted_top_level_schemes() {
        assert!(!permitted_page_navigation("javascript:alert(1)"));
        assert!(!permitted_page_navigation("file:///C:/secret.txt"));
        assert!(!permitted_page_navigation("data:text/html,hi"));
        assert!(permitted_page_navigation("https://example.com/login"));
    }
    #[test]
    fn sensitive_permissions_are_not_silently_granted() {
        assert!(matches!(
            site_permission_policy(PermissionKind::Geolocation),
            PermissionResponse::Default
        ));
        assert!(matches!(
            site_permission_policy(PermissionKind::Microphone),
            PermissionResponse::Default
        ));
        assert!(matches!(
            site_permission_policy(PermissionKind::ClipboardRead),
            PermissionResponse::Deny
        ));
    }
    #[test]
    fn escaped_library_data() {
        let mut data = BrowserData::default();
        data.toggle_bookmark(
            "https://example.com/?q=<script>",
            "<script>alert('x')</script>",
        );
        let doc = render_library(BOOKMARKS, &data);
        assert!(doc.contains("&lt;script&gt;"));
        assert!(!doc.contains("<script>alert('x')</script>"));
    }
}
