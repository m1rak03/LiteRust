//! Platform-independent browser metadata and policies.
pub mod google_passwords;
pub mod import;
pub mod layout;
pub mod navigation;
pub mod network_block;
pub mod newtab;
pub mod profile;
pub mod security;
pub mod storage;
pub mod vpn;
#[cfg(windows)]
pub mod vpn_platform;

pub mod icons;

#[cfg(windows)]
pub mod system_vpn;
