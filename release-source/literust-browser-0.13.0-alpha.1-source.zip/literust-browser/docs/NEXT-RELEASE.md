# Work in progress: next release

Implemented locally, not published:
- Persistent choice of Google, Yandex, DuckDuckGo, Bing, Brave for address bar and new tab.
- Short CSS animations, respecting prefers-reduced-motion.
- NSIS compact installer draft with Desktop/Start Menu shortcuts and uninstall registration.

Validation so far: 40 platform-independent tests pass; Windows-target Clippy passes.

Remaining release gates:
- Add provider-specific search/persistence tests and UI regression checks.
- Installer: validate WebView2 availability after bootstrapper, handle download/install failure, add branded icon, test install/uninstall on Windows. Do not publish draft installer as complete.
- Tor requested explicitly with bridges: implement a separate profile, owned Tor process, encrypted bridge storage, transport validation, explicit readiness and fail-closed behavior. Tor traffic does not confer Tor Browser fingerprint protection.
- Official Tor Expert Bundle 16.0.1 downloaded from dist.torproject.org to /workspace/tor-windows.tar.gz; signature verification and integration NOT yet done.
- Reduce package size through compressed installation and optional online WebView2 bootstrapper. Keep offline distribution available. No RAM benchmark claim yet.
- Build, run Windows native startup and installation checks, publish a new version via GitHub Actions only after checks pass.

Existing published release remains 0.11.0-alpha.2. Never replace it with these unfinished edits.
